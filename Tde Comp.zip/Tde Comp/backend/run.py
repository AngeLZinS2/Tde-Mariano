#!/usr/bin/env python3
import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
        print("✅ Dependências instaladas com sucesso!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Erro ao instalar dependências: {e}")
        sys.exit(1)

def run_server():
    """Run the Flask server"""
    try:
        print("🚀 Iniciando servidor backend...")
        print("📍 Servidor rodando em: http://localhost:5000")
        print("📊 Banco de dados: SQLite3 (ong_database.db)")
        print("🔐 JWT Secret configurado")
        print("\n" + "="*50)
        subprocess.run([sys.executable, 'app.py'])
    except KeyboardInterrupt:
        print("\n🛑 Servidor interrompido pelo usuário")
    except Exception as e:
        print(f"❌ Erro ao executar servidor: {e}")

if __name__ == '__main__':
    # Change to backend directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    print("🔧 Configurando ambiente backend...")
    install_requirements()
    run_server()