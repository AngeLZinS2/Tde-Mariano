from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import jwt
import bcrypt
from datetime import datetime, timedelta
import re
from functools import wraps

app = Flask(__name__)
CORS(app)

# JWT Secret Key
JWT_SECRET = "M1nh4ch4v3qu3s3r4ut1l1z4d4p4r4cr1pt0gr4f14d0t0k3nJWT"

# Database initialization
def init_db():
    conn = sqlite3.connect('ong_database.db')
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            cpf TEXT UNIQUE NOT NULL,
            phone TEXT,
            photo TEXT,
            password_hash TEXT NOT NULL,
            is_admin BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Campaigns table with approval status
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS campaigns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            target_amount REAL NOT NULL,
            current_amount REAL DEFAULT 0,
            end_date DATE NOT NULL,
            image_url TEXT,
            is_active BOOLEAN DEFAULT 1,
            is_approved BOOLEAN DEFAULT 0,
            approval_date TIMESTAMP,
            approved_by INTEGER,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id),
            FOREIGN KEY (approved_by) REFERENCES users (id)
        )
    ''')
    
    # Donations table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS donations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER NOT NULL,
            user_id INTEGER,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            donor_name TEXT,
            donor_email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (campaign_id) REFERENCES campaigns (id),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Donors view (for statistics)
    cursor.execute('''
        CREATE VIEW IF NOT EXISTS donors_stats AS
        SELECT 
            COALESCE(u.id, 0) as id,
            COALESCE(u.name, d.donor_name) as name,
            COALESCE(u.email, d.donor_email) as email,
            MAX(d.created_at) as last_donation_date,
            SUM(d.amount) as total_donated,
            COUNT(d.id) as donations_count
        FROM donations d
        LEFT JOIN users u ON d.user_id = u.id
        WHERE d.donor_name IS NOT NULL OR u.name IS NOT NULL
        GROUP BY COALESCE(u.id, d.donor_email)
        ORDER BY total_donated DESC
    ''')
    
    # Create admin user if not exists
    admin_email = 'admin@unifan.br'
    existing_admin = cursor.execute('SELECT id FROM users WHERE email = ?', (admin_email,)).fetchone()
    
    if not existing_admin:
        admin_password_hash = bcrypt.hashpw('12345678'.encode('utf-8'), bcrypt.gensalt())
        cursor.execute('''
            INSERT INTO users (name, email, cpf, phone, password_hash, is_admin)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('Administrador do Sistema', admin_email, '00000000000', '(75)4477-4774', admin_password_hash, 1))
        print("✅ Admin user created successfully!")
    
    conn.commit()
    conn.close()

# JWT token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            current_user_id = data['user_id']
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(current_user_id, *args, **kwargs)
    
    return decorated

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            current_user_id = data['user_id']
            
            # Check if user is admin
            conn = get_db_connection()
            user = conn.execute('SELECT is_admin FROM users WHERE id = ?', (current_user_id,)).fetchone()
            conn.close()
            
            if not user or not user['is_admin']:
                return jsonify({'message': 'Admin access required'}), 403
                
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(current_user_id, *args, **kwargs)
    
    return decorated

# Helper functions
def validate_cpf(cpf):
    cpf = re.sub(r'[^0-9]', '', cpf)
    
    if len(cpf) != 11 or cpf == cpf[0] * 11:
        return False
    
    # Validate first digit
    sum1 = sum(int(cpf[i]) * (10 - i) for i in range(9))
    digit1 = (sum1 * 10) % 11
    if digit1 == 10:
        digit1 = 0
    
    if int(cpf[9]) != digit1:
        return False
    
    # Validate second digit
    sum2 = sum(int(cpf[i]) * (11 - i) for i in range(10))
    digit2 = (sum2 * 10) % 11
    if digit2 == 10:
        digit2 = 0
    
    if int(cpf[10]) != digit2:
        return False
    
    return True

def get_db_connection():
    conn = sqlite3.connect('ong_database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Auth routes
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'email', 'cpf', 'password', 'confirmPassword']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'success': False, 'message': f'{field} é obrigatório'}), 400
    
    # Validate password confirmation
    if data['password'] != data['confirmPassword']:
        return jsonify({'success': False, 'message': 'Senhas não coincidem'}), 400
    
    # Validate CPF
    if not validate_cpf(data['cpf']):
        return jsonify({'success': False, 'message': 'CPF inválido'}), 400
    
    # Validate email format
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(email_pattern, data['email']):
        return jsonify({'success': False, 'message': 'Email inválido'}), 400
    
    conn = get_db_connection()
    
    # Check if email already exists
    existing_user = conn.execute('SELECT id FROM users WHERE email = ?', (data['email'],)).fetchone()
    if existing_user:
        conn.close()
        return jsonify({'success': False, 'message': 'Email já está em uso'}), 400
    
    # Check if CPF already exists
    existing_cpf = conn.execute('SELECT id FROM users WHERE cpf = ?', (data['cpf'],)).fetchone()
    if existing_cpf:
        conn.close()
        return jsonify({'success': False, 'message': 'CPF já está cadastrado'}), 400
    
    # Hash password
    password_hash = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    
    # Insert user
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO users (name, email, cpf, password_hash, is_admin)
        VALUES (?, ?, ?, ?, ?)
    ''', (data['name'], data['email'], data['cpf'], password_hash, 0))
    
    user_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Generate JWT token
    token = jwt.encode({
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(days=30)
    }, JWT_SECRET, algorithm='HS256')
    
    return jsonify({
        'success': True,
        'message': 'Cadastro realizado com sucesso!',
        'token': token,
        'user': {
            'id': user_id,
            'name': data['name'],
            'email': data['email'],
            'cpf': data['cpf'],
            'isAdmin': False
        }
    })

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data.get('email') or not data.get('password'):
        return jsonify({'success': False, 'message': 'Email e senha são obrigatórios'}), 400
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE email = ?', (data['email'],)).fetchone()
    conn.close()
    
    if not user or not bcrypt.checkpw(data['password'].encode('utf-8'), user['password_hash']):
        return jsonify({'success': False, 'message': 'Email ou senha inválidos'}), 401
    
    # Generate JWT token
    token = jwt.encode({
        'user_id': user['id'],
        'exp': datetime.utcnow() + timedelta(days=30)
    }, JWT_SECRET, algorithm='HS256')
    
    return jsonify({
        'success': True,
        'message': 'Login realizado com sucesso!',
        'token': token,
        'user': {
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'cpf': user['cpf'],
            'phone': user['phone'],
            'photo': user['photo'],
            'isAdmin': bool(user['is_admin'])
        }
    })

@app.route('/api/auth/me', methods=['GET'])
@token_required
def get_current_user(current_user_id):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (current_user_id,)).fetchone()
    conn.close()
    
    if not user:
        return jsonify({'message': 'Usuário não encontrado'}), 404
    
    return jsonify({
        'id': user['id'],
        'name': user['name'],
        'email': user['email'],
        'cpf': user['cpf'],
        'phone': user['phone'],
        'photo': user['photo'],
        'isAdmin': bool(user['is_admin'])
    })

@app.route('/api/auth/update-profile', methods=['PUT'])
@token_required
def update_profile(current_user_id):
    data = request.get_json()
    
    conn = get_db_connection()
    
    # Build update query dynamically
    update_fields = []
    values = []
    
    if data.get('name'):
        update_fields.append('name = ?')
        values.append(data['name'])
    
    if data.get('email'):
        # Check if email is already taken by another user
        existing_user = conn.execute('SELECT id FROM users WHERE email = ? AND id != ?', 
                                   (data['email'], current_user_id)).fetchone()
        if existing_user:
            conn.close()
            return jsonify({'success': False, 'message': 'Email já está em uso'}), 400
        
        update_fields.append('email = ?')
        values.append(data['email'])
    
    if data.get('phone'):
        update_fields.append('phone = ?')
        values.append(data['phone'])
    
    if data.get('photo'):
        update_fields.append('photo = ?')
        values.append(data['photo'])
    
    if update_fields:
        values.append(current_user_id)
        query = f"UPDATE users SET {', '.join(update_fields)} WHERE id = ?"
        conn.execute(query, values)
        conn.commit()
    
    # Get updated user
    user = conn.execute('SELECT * FROM users WHERE id = ?', (current_user_id,)).fetchone()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': 'Perfil atualizado com sucesso!',
        'user': {
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'cpf': user['cpf'],
            'phone': user['phone'],
            'photo': user['photo'],
            'isAdmin': bool(user['is_admin'])
        }
    })

@app.route('/api/auth/change-password', methods=['PUT'])
@token_required
def change_password(current_user_id):
    data = request.get_json()
    
    if not data.get('currentPassword') or not data.get('newPassword'):
        return jsonify({'success': False, 'message': 'Senhas são obrigatórias'}), 400
    
    conn = get_db_connection()
    user = conn.execute('SELECT password_hash FROM users WHERE id = ?', (current_user_id,)).fetchone()
    
    if not user or not bcrypt.checkpw(data['currentPassword'].encode('utf-8'), user['password_hash']):
        conn.close()
        return jsonify({'success': False, 'message': 'Senha atual incorreta'}), 400
    
    # Hash new password
    new_password_hash = bcrypt.hashpw(data['newPassword'].encode('utf-8'), bcrypt.gensalt())
    
    # Update password
    conn.execute('UPDATE users SET password_hash = ? WHERE id = ?', 
                (new_password_hash, current_user_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Senha alterada com sucesso!'})

# Admin routes
@app.route('/api/admin/users', methods=['GET'])
@admin_required
def get_all_users(current_user_id):
    conn = get_db_connection()
    users = conn.execute('''
        SELECT u.*, 
               COUNT(DISTINCT c.id) as campaigns_count,
               COUNT(DISTINCT d.id) as donations_count,
               COALESCE(SUM(d.amount), 0) as total_donated
        FROM users u
        LEFT JOIN campaigns c ON u.id = c.created_by
        LEFT JOIN donations d ON u.id = d.user_id
        GROUP BY u.id
        ORDER BY u.created_at DESC
    ''').fetchall()
    conn.close()
    
    users_list = []
    for user in users:
        users_list.append({
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'cpf': user['cpf'],
            'phone': user['phone'],
            'isAdmin': bool(user['is_admin']),
            'createdAt': user['created_at'],
            'campaignsCount': user['campaigns_count'],
            'donationsCount': user['donations_count'],
            'totalDonated': user['total_donated']
        })
    
    return jsonify(users_list)

@app.route('/api/admin/users/<int:user_id>/toggle-admin', methods=['PUT'])
@admin_required
def toggle_user_admin(current_user_id, user_id):
    if current_user_id == user_id:
        return jsonify({'success': False, 'message': 'Você não pode alterar seu próprio status de admin'}), 400
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    
    if not user:
        conn.close()
        return jsonify({'success': False, 'message': 'Usuário não encontrado'}), 404
    
    new_admin_status = 0 if user['is_admin'] else 1
    conn.execute('UPDATE users SET is_admin = ? WHERE id = ?', (new_admin_status, user_id))
    conn.commit()
    conn.close()
    
    status_text = 'promovido a administrador' if new_admin_status else 'removido da administração'
    return jsonify({'success': True, 'message': f'Usuário {status_text} com sucesso!'})

@app.route('/api/admin/stats', methods=['GET'])
@admin_required
def get_admin_stats(current_user_id):
    conn = get_db_connection()
    
    # Get general statistics
    stats = {}
    
    # Total users
    stats['totalUsers'] = conn.execute('SELECT COUNT(*) as count FROM users').fetchone()['count']
    
    # Total campaigns
    stats['totalCampaigns'] = conn.execute('SELECT COUNT(*) as count FROM campaigns').fetchone()['count']
    
    # Active campaigns
    stats['activeCampaigns'] = conn.execute('SELECT COUNT(*) as count FROM campaigns WHERE is_active = 1 AND is_approved = 1').fetchone()['count']
    
    # Total donations
    stats['totalDonations'] = conn.execute('SELECT COUNT(*) as count FROM donations').fetchone()['count']
    
    # Total amount donated
    total_amount = conn.execute('SELECT COALESCE(SUM(amount), 0) as total FROM donations').fetchone()['total']
    stats['totalAmountDonated'] = total_amount
    
    # Recent activity
    recent_users = conn.execute('''
        SELECT COUNT(*) as count FROM users 
        WHERE created_at >= datetime('now', '-30 days')
    ''').fetchone()['count']
    stats['recentUsers'] = recent_users
    
    recent_donations = conn.execute('''
        SELECT COUNT(*) as count FROM donations 
        WHERE created_at >= datetime('now', '-30 days')
    ''').fetchone()['count']
    stats['recentDonations'] = recent_donations
    
    conn.close()
    
    return jsonify(stats)

# Admin campaigns management routes
@app.route('/api/admin/campaigns', methods=['GET'])
@admin_required
def get_all_campaigns_admin(current_user_id):
    conn = get_db_connection()
    campaigns = conn.execute('''
        SELECT c.*, u.name as created_by_name, a.name as approved_by_name,
               COUNT(d.id) as donations_count
        FROM campaigns c 
        LEFT JOIN users u ON c.created_by = u.id 
        LEFT JOIN users a ON c.approved_by = a.id
        LEFT JOIN donations d ON c.id = d.campaign_id
        GROUP BY c.id
        ORDER BY c.created_at DESC
    ''').fetchall()
    conn.close()
    
    campaigns_list = []
    for campaign in campaigns:
        campaigns_list.append({
            'id': campaign['id'],
            'title': campaign['title'],
            'description': campaign['description'],
            'targetAmount': campaign['target_amount'],
            'currentAmount': campaign['current_amount'],
            'endDate': campaign['end_date'],
            'imageUrl': campaign['image_url'],
            'isActive': bool(campaign['is_active']),
            'isApproved': bool(campaign['is_approved']),
            'approvalDate': campaign['approval_date'],
            'createdBy': campaign['created_by_name'] or 'Usuário',
            'approvedBy': campaign['approved_by_name'],
            'createdAt': campaign['created_at'],
            'donationsCount': campaign['donations_count'] or 0
        })
    
    return jsonify(campaigns_list)

@app.route('/api/admin/campaigns/<int:campaign_id>/approve', methods=['PUT'])
@admin_required
def approve_campaign(current_user_id, campaign_id):
    conn = get_db_connection()
    
    campaign = conn.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,)).fetchone()
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada'}), 404
    
    # Toggle approval status
    new_approval_status = 0 if campaign['is_approved'] else 1
    approval_date = datetime.utcnow().isoformat() if new_approval_status else None
    approved_by = current_user_id if new_approval_status else None
    
    conn.execute('''
        UPDATE campaigns 
        SET is_approved = ?, approval_date = ?, approved_by = ?
        WHERE id = ?
    ''', (new_approval_status, approval_date, approved_by, campaign_id))
    conn.commit()
    conn.close()
    
    status_text = 'aprovada' if new_approval_status else 'rejeitada'
    return jsonify({'success': True, 'message': f'Campanha {status_text} com sucesso!'})

@app.route('/api/admin/campaigns/<int:campaign_id>', methods=['PUT'])
@admin_required
def update_campaign_admin(current_user_id, campaign_id):
    data = request.get_json()
    
    conn = get_db_connection()
    
    campaign = conn.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,)).fetchone()
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada'}), 404
    
    # Build update query dynamically
    update_fields = []
    values = []
    
    if data.get('title'):
        update_fields.append('title = ?')
        values.append(data['title'])
    
    if data.get('description'):
        update_fields.append('description = ?')
        values.append(data['description'])
    
    if data.get('targetAmount'):
        update_fields.append('target_amount = ?')
        values.append(data['targetAmount'])
    
    if data.get('endDate'):
        update_fields.append('end_date = ?')
        values.append(data['endDate'])
    
    if data.get('imageUrl'):
        update_fields.append('image_url = ?')
        values.append(data['imageUrl'])
    
    if update_fields:
        values.append(campaign_id)
        query = f"UPDATE campaigns SET {', '.join(update_fields)} WHERE id = ?"
        conn.execute(query, values)
        conn.commit()
    
    conn.close()
    
    return jsonify({'success': True, 'message': 'Campanha atualizada com sucesso!'})

@app.route('/api/admin/campaigns/<int:campaign_id>', methods=['DELETE'])
@admin_required
def delete_campaign(current_user_id, campaign_id):
    conn = get_db_connection()
    
    campaign = conn.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,)).fetchone()
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada'}), 404
    
    # Check if campaign has donations
    donations = conn.execute('SELECT COUNT(*) as count FROM donations WHERE campaign_id = ?', (campaign_id,)).fetchone()
    if donations['count'] > 0:
        conn.close()
        return jsonify({'success': False, 'message': 'Não é possível excluir campanha que já recebeu doações'}), 400
    
    # Delete campaign
    conn.execute('DELETE FROM campaigns WHERE id = ?', (campaign_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Campanha excluída com sucesso!'})

# Campaigns routes
@app.route('/api/campaigns', methods=['GET'])
def get_campaigns():
    conn = get_db_connection()
    campaigns = conn.execute('''
        SELECT c.*, u.name as created_by_name 
        FROM campaigns c 
        LEFT JOIN users u ON c.created_by = u.id 
        ORDER BY c.created_at DESC
    ''').fetchall()
    conn.close()
    
    campaigns_list = []
    for campaign in campaigns:
        campaigns_list.append({
            'id': campaign['id'],
            'title': campaign['title'],
            'description': campaign['description'],
            'targetAmount': campaign['target_amount'],
            'currentAmount': campaign['current_amount'],
            'endDate': campaign['end_date'],
            'imageUrl': campaign['image_url'],
            'isActive': bool(campaign['is_active']),
            'isApproved': bool(campaign['is_approved']),
            'createdBy': campaign['created_by_name'] or 'Usuário',
            'createdAt': campaign['created_at']
        })
    
    return jsonify(campaigns_list)

@app.route('/api/campaigns/active', methods=['GET'])
def get_active_campaigns():
    conn = get_db_connection()
    campaigns = conn.execute('''
        SELECT c.*, u.name as created_by_name 
        FROM campaigns c 
        LEFT JOIN users u ON c.created_by = u.id 
        WHERE c.is_active = 1 AND c.is_approved = 1 AND c.end_date >= date('now')
        ORDER BY c.created_at DESC
    ''').fetchall()
    conn.close()
    
    campaigns_list = []
    for campaign in campaigns:
        campaigns_list.append({
            'id': campaign['id'],
            'title': campaign['title'],
            'description': campaign['description'],
            'targetAmount': campaign['target_amount'],
            'currentAmount': campaign['current_amount'],
            'endDate': campaign['end_date'],
            'imageUrl': campaign['image_url'],
            'isActive': bool(campaign['is_active']),
            'isApproved': bool(campaign['is_approved']),
            'createdBy': campaign['created_by_name'] or 'Usuário',
            'createdAt': campaign['created_at']
        })
    
    return jsonify(campaigns_list)

@app.route('/api/campaigns/my-campaigns', methods=['GET'])
@token_required
def get_my_campaigns(current_user_id):
    conn = get_db_connection()
    campaigns = conn.execute('''
        SELECT c.*, u.name as created_by_name,
               COUNT(d.id) as donations_count
        FROM campaigns c 
        LEFT JOIN users u ON c.created_by = u.id 
        LEFT JOIN donations d ON c.id = d.campaign_id
        WHERE c.created_by = ?
        GROUP BY c.id
        ORDER BY c.created_at DESC
    ''', (current_user_id,)).fetchall()
    conn.close()
    
    campaigns_list = []
    for campaign in campaigns:
        campaigns_list.append({
            'id': campaign['id'],
            'title': campaign['title'],
            'description': campaign['description'],
            'targetAmount': campaign['target_amount'],
            'currentAmount': campaign['current_amount'],
            'endDate': campaign['end_date'],
            'imageUrl': campaign['image_url'],
            'isActive': bool(campaign['is_active']),
            'isApproved': bool(campaign['is_approved']),
            'createdBy': campaign['created_by_name'] or 'Usuário',
            'createdAt': campaign['created_at'],
            'donationsCount': campaign['donations_count'] or 0
        })
    
    return jsonify(campaigns_list)

@app.route('/api/campaigns', methods=['POST'])
@token_required
def create_campaign(current_user_id):
    data = request.get_json()
    
    required_fields = ['title', 'description', 'targetAmount', 'endDate']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'success': False, 'message': f'{field} é obrigatório'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO campaigns (title, description, target_amount, end_date, image_url, created_by, is_approved)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data['title'],
        data['description'],
        data['targetAmount'],
        data['endDate'],
        data.get('imageUrl', 'https://images.pexels.com/photos/6647100/pexels-photo-6647100.jpeg?auto=compress&cs=tinysrgb&w=800'),
        current_user_id,
        0  # Campaigns need approval by default
    ))
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Campanha criada com sucesso! Aguardando aprovação do administrador.'})

@app.route('/api/campaigns/<int:campaign_id>', methods=['PUT'])
@token_required
def update_campaign(current_user_id, campaign_id):
    data = request.get_json()
    
    conn = get_db_connection()
    
    # Check if campaign exists and belongs to current user (or user is admin)
    user = conn.execute('SELECT is_admin FROM users WHERE id = ?', (current_user_id,)).fetchone()
    is_admin = user and user['is_admin']
    
    if is_admin:
        campaign = conn.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,)).fetchone()
    else:
        campaign = conn.execute('SELECT * FROM campaigns WHERE id = ? AND created_by = ?', 
                               (campaign_id, current_user_id)).fetchone()
    
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada ou você não tem permissão para editá-la'}), 404
    
    # Build update query dynamically
    update_fields = []
    values = []
    
    if data.get('title'):
        update_fields.append('title = ?')
        values.append(data['title'])
    
    if data.get('description'):
        update_fields.append('description = ?')
        values.append(data['description'])
    
    if data.get('targetAmount'):
        update_fields.append('target_amount = ?')
        values.append(data['targetAmount'])
    
    if data.get('endDate'):
        update_fields.append('end_date = ?')
        values.append(data['endDate'])
    
    if data.get('imageUrl'):
        update_fields.append('image_url = ?')
        values.append(data['imageUrl'])
    
    if update_fields:
        values.append(campaign_id)
        query = f"UPDATE campaigns SET {', '.join(update_fields)} WHERE id = ?"
        conn.execute(query, values)
        conn.commit()
    
    conn.close()
    
    return jsonify({'success': True, 'message': 'Campanha atualizada com sucesso!'})

@app.route('/api/campaigns/<int:campaign_id>/toggle-status', methods=['PUT'])
@token_required
def toggle_campaign_status(current_user_id, campaign_id):
    conn = get_db_connection()
    
    # Check if campaign exists and belongs to current user (or user is admin)
    user = conn.execute('SELECT is_admin FROM users WHERE id = ?', (current_user_id,)).fetchone()
    is_admin = user and user['is_admin']
    
    if is_admin:
        campaign = conn.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,)).fetchone()
    else:
        campaign = conn.execute('SELECT * FROM campaigns WHERE id = ? AND created_by = ?', 
                               (campaign_id, current_user_id)).fetchone()
    
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada ou você não tem permissão para alterá-la'}), 404
    
    # Toggle status
    new_status = 0 if campaign['is_active'] else 1
    conn.execute('UPDATE campaigns SET is_active = ? WHERE id = ?', (new_status, campaign_id))
    conn.commit()
    conn.close()
    
    status_text = 'ativada' if new_status else 'encerrada'
    return jsonify({'success': True, 'message': f'Campanha {status_text} com sucesso!'})

# Donations routes
@app.route('/api/donations', methods=['POST'])
@token_required
def make_donation(current_user_id):
    data = request.get_json()
    
    required_fields = ['campaignId', 'amount', 'paymentMethod']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'success': False, 'message': f'{field} é obrigatório'}), 400
    
    conn = get_db_connection()
    
    # Check if campaign exists, is active and approved
    campaign = conn.execute('SELECT * FROM campaigns WHERE id = ? AND is_active = 1 AND is_approved = 1', 
                           (data['campaignId'],)).fetchone()
    if not campaign:
        conn.close()
        return jsonify({'success': False, 'message': 'Campanha não encontrada, inativa ou não aprovada'}), 404
    
    # Insert donation
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO donations (campaign_id, user_id, amount, payment_method, donor_name, donor_email)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        data['campaignId'],
        current_user_id,
        data['amount'],
        data['paymentMethod'],
        data.get('donorName'),
        data.get('donorEmail')
    ))
    
    # Update campaign current amount
    cursor.execute('''
        UPDATE campaigns 
        SET current_amount = current_amount + ? 
        WHERE id = ?
    ''', (data['amount'], data['campaignId']))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'Doação de R$ {data["amount"]:.2f} realizada com sucesso! Obrigado por contribuir.'
    })

@app.route('/api/donations/payment-methods', methods=['GET'])
def get_payment_methods():
    methods = [
        'Cartão de Crédito',
        'Cartão de Débito',
        'PIX',
        'Boleto Bancário',
        'Transferência Bancária'
    ]
    return jsonify(methods)

# Donors routes
@app.route('/api/donors', methods=['GET'])
@token_required
def get_donors(current_user_id):
    conn = get_db_connection()
    donors = conn.execute('SELECT * FROM donors_stats ORDER BY total_donated DESC').fetchall()
    conn.close()
    
    donors_list = []
    for donor in donors:
        donors_list.append({
            'id': donor['id'],
            'name': donor['name'],
            'email': donor['email'],
            'lastDonationDate': donor['last_donation_date'],
            'totalDonated': donor['total_donated'],
            'donationsCount': donor['donations_count']
        })
    
    return jsonify(donors_list)

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)