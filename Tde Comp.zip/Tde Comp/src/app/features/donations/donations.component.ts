import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { CampaignsService, Campaign } from '../../core/services/campaigns.service';
import { DonationsService } from '../../core/services/donations.service';
import { DonationModalComponent } from './donation-modal/donation-modal.component';

@Component({
  selector: 'app-donations',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDialogModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="page-header">
          <h1>
            <mat-icon>volunteer_activism</mat-icon>
            Campanhas de Doação
          </h1>
          <p>Escolha uma campanha e contribua para transformar vidas</p>
        </div>

        <div *ngIf="isLoading" class="loading-spinner">
          <mat-spinner></mat-spinner>
          <p>Carregando campanhas...</p>
        </div>

        <div *ngIf="!isLoading" class="campaigns-section">
          <div class="campaigns-grid">
            <mat-card *ngFor="let campaign of campaigns" class="campaign-card">
              <div class="campaign-image-container">
                <img [src]="campaign.imageUrl" 
                     [alt]="campaign.title" 
                     class="campaign-image"
                     (error)="onImageError($event)">
                <div class="campaign-status" [class.inactive]="!campaign.isActive">
                  {{ campaign.isActive ? 'Ativa' : 'Encerrada' }}
                </div>
              </div>

              <mat-card-content>
                <h3 class="campaign-title">{{ campaign.title }}</h3>
                <p class="campaign-description">{{ campaign.description }}</p>

                <div class="progress-section">
                  <div class="progress-header">
                    <span class="progress-label">Progresso da Campanha</span>
                    <span class="progress-percentage">{{ getProgressPercentage(campaign) }}%</span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill" 
                         [style.width.%]="getProgressPercentage(campaign)">
                    </div>
                  </div>
                  <div class="progress-details">
                    <div class="amount-raised">
                      <span class="label">Arrecadado:</span>
                      <span class="amount">R$ {{ campaign.currentAmount | number:'1.2-2' }}</span>
                    </div>
                    <div class="amount-target">
                      <span class="label">Meta:</span>
                      <span class="amount">R$ {{ campaign.targetAmount | number:'1.2-2' }}</span>
                    </div>
                  </div>
                </div>

                <div class="campaign-info">
                  <div class="info-item">
                    <mat-icon>event</mat-icon>
                    <span>Encerra em: {{ campaign.endDate | date:'dd/MM/yyyy' }}</span>
                  </div>
                  <div class="info-item">
                    <mat-icon>person</mat-icon>
                    <span>Por: {{ campaign.createdBy }}</span>
                  </div>
                </div>
              </mat-card-content>

              <mat-card-actions>
                <button mat-button color="primary" (click)="viewCampaignDetails(campaign)">
                  Ver Detalhes
                </button>
                <button mat-raised-button 
                        color="primary" 
                        [disabled]="!campaign.isActive"
                        (click)="openDonationModal(campaign)">
                  <mat-icon>favorite</mat-icon>
                  Doar Agora
                </button>
              </mat-card-actions>
            </mat-card>
          </div>

          <div *ngIf="campaigns.length === 0" class="no-campaigns">
            <mat-icon>campaign</mat-icon>
            <h3>Nenhuma campanha disponível</h3>
            <p>No momento não há campanhas ativas para doação.</p>
          </div>
        </div>

        <!-- Statistics Section -->
        <section class="statistics-section">
          <h2>Impacto das Doações</h2>
          <div class="stats-grid">
            <div class="stat-item">
              <mat-icon>people</mat-icon>
              <div class="stat-content">
                <span class="stat-number">1,250+</span>
                <span class="stat-label">Pessoas Beneficiadas</span>
              </div>
            </div>
            <div class="stat-item">
              <mat-icon>monetization_on</mat-icon>
              <div class="stat-content">
                <span class="stat-number">R$ 850K</span>
                <span class="stat-label">Total Arrecadado</span>
              </div>
            </div>
            <div class="stat-item">
              <mat-icon>campaign</mat-icon>
              <div class="stat-content">
                <span class="stat-number">{{ campaigns.length }}</span>
                <span class="stat-label">Campanhas Ativas</span>
              </div>
            </div>
            <div class="stat-item">
              <mat-icon>favorite</mat-icon>
              <div class="stat-content">
                <span class="stat-number">2,800+</span>
                <span class="stat-label">Doadores</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  `,
  styles: [`
    .page-header {
      text-align: center;
      margin-bottom: 3rem;
    }

    .page-header h1 {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .page-header h1 mat-icon {
      font-size: 32px;
      color: var(--primary-green);
    }

    .page-header p {
      color: var(--text-light);
      margin: 0;
      font-size: 1.1rem;
    }

    .loading-spinner {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 3rem;
    }

    .loading-spinner p {
      margin-top: 1rem;
      color: var(--text-light);
    
    }

    .campaigns-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 24px;
      margin-bottom: 3rem;
    }

    .campaign-card {
      overflow: hidden;
      transition: transform 0.2s, box-shadow 0.2s;
      height: fit-content;
    }

    .campaign-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    }

    .campaign-image-container {
      position: relative;
      height: 200px;
      overflow: hidden;
    }

    .campaign-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .campaign-status {
      position: absolute;
      top: 12px;
      right: 12px;
      background: var(--success);
      color: white;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }

    .campaign-status.inactive {
      background: var(--text-light);
    }

    .campaign-title {
      margin: 0 0 12px 0;
      color: var(--text-dark);
      font-size: 1.2rem;
      font-weight: 500;
    }

    .campaign-description {
      color: var(--text-light);
      font-size: 14px;
      margin-bottom: 20px;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.4;
    }

    .progress-section {
      margin-bottom: 20px;
    }

    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .progress-label {
      font-size: 14px;
      color: var(--text-dark);
      font-weight: 500;
    }

    .progress-percentage {
      font-size: 14px;
      color: var(--primary-green);
      font-weight: 600;
    }

    .progress-bar {
      width: 100%;
      height: 8px;
      background: #e0e0e0;
      border-radius: 4px;
      overflow: hidden;
      margin-bottom: 12px;
    }

    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--primary-green), var(--accent-green));
      transition: width 0.3s ease;
    }

    .progress-details {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
    }

    .progress-details .label {
      color: var(--text-light);
    }

    .progress-details .amount {
      color: var(--text-dark);
      font-weight: 500;
    }

    .campaign-info {
      margin-bottom: 16px;
    }

    .info-item {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      font-size: 14px;
      color: var(--text-light);
    }

    .info-item mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    mat-card-actions {
      display: flex;
      justify-content: space-between;
      padding: 16px;
    }

    .no-campaigns {
      text-align: center;
      padding: 3rem;
      color: var(--text-light);
    }

    .no-campaigns mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 16px;
    }

    .no-campaigns h3 {
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .statistics-section {
      background: white;
      padding: 3rem 0;
      margin-top: 3rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .statistics-section h2 {
      text-align: center;
      margin: 0 0 2rem 0;
      color: var(--text-dark);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 2rem;
    }

    .stat-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 1rem;
      text-align: left;
    }

    .stat-item mat-icon {
      font-size: 40px;
      width: 40px;
      height: 40px;
      color: var(--primary-blue);
    }

    .stat-content {
      display: flex;
      flex-direction: column;
    }

    .stat-number {
      font-size: 1.8rem;
      font-weight: 600;
      color: var(--primary-green);
    }

    .stat-label {
      font-size: 0.9rem;
      color: var(--text-light);
    }

    @media (max-width: 768px) {
      .campaigns-grid {
        grid-template-columns: 1fr;
        gap: 16px;
      }

      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
      }

      .stat-item {
        flex-direction: column;
        text-align: center;
        gap: 8px;
      }
    }

    @media (max-width: 480px) {
      .stats-grid {
        grid-template-columns: 1fr;
      }

      mat-card-actions {
        flex-direction: column;
        gap: 8px;
      }
    }
  `]
})
export class DonationsComponent implements OnInit {
  campaigns: Campaign[] = [];
  isLoading = true;

  constructor(
    private campaignsService: CampaignsService,
    private donationsService: DonationsService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadCampaigns();
  }

  loadCampaigns() {
    this.isLoading = true;
    
    this.campaignsService.getAllCampaigns().subscribe({
      next: (campaigns) => {
        this.campaigns = campaigns;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Erro ao carregar campanhas', 'Fechar', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  getProgressPercentage(campaign: Campaign): number {
    return Math.min(Math.round((campaign.currentAmount / campaign.targetAmount) * 100), 100);
  }

  viewCampaignDetails(campaign: Campaign) {
    // In a real application, this would navigate to a campaign details page
    console.log('Viewing campaign details:', campaign);
  }

  openDonationModal(campaign: Campaign) {
    const dialogRef = this.dialog.open(DonationModalComponent, {
      width: '500px',
      data: { campaign }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Refresh campaigns to show updated amounts
        this.loadCampaigns();
      }
    });
  }

  onImageError(event: any) {
    event.target.src = 'https://images.pexels.com/photos/6647100/pexels-photo-6647100.jpeg?auto=compress&cs=tinysrgb&w=800';
  }
}