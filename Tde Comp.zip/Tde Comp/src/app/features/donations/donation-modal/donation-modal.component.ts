import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Campaign } from '../../../core/services/campaigns.service';
import { DonationsService } from '../../../core/services/donations.service';

@Component({
  selector: 'app-donation-modal',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="donation-modal">
      <div class="modal-header">
        <h2 mat-dialog-title>
          <mat-icon>favorite</mat-icon>
          Fazer Doação
        </h2>
        <button mat-icon-button mat-dialog-close>
          <mat-icon>close</mat-icon>
        </button>
      </div>

      <mat-dialog-content>
        <div class="campaign-info">
          <h3>{{ campaign.title }}</h3>
          <div class="progress-info">
            <div class="progress-bar">
              <div class="progress-fill" [style.width.%]="getProgressPercentage()"></div>
            </div>
            <div class="progress-text">
              <span>R$ {{ campaign.currentAmount | number:'1.2-2' }} de R$ {{ campaign.targetAmount | number:'1.2-2' }}</span>
              <span class="percentage">{{ getProgressPercentage() }}%</span>
            </div>
          </div>
        </div>

        <form [formGroup]="donationForm" (ngSubmit)="onSubmit()">
          <div class="amount-section">
            <h4>Valor da Doação</h4>
            <div class="quick-amounts">
              <button type="button" 
                      mat-stroked-button 
                      *ngFor="let amount of quickAmounts"
                      (click)="selectAmount(amount)"
                      [class.selected]="donationForm.get('amount')?.value === amount">
                R$ {{ amount }}
              </button>
            </div>
            
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Valor personalizado</mat-label>
              <input matInput
                     type="number"
                     formControlName="amount"
                     placeholder="0,00"
                     min="5"
                     step="0.01">
              <span matTextPrefix>R$ </span>
              <mat-error *ngIf="donationForm.get('amount')?.hasError('required')">
                Valor é obrigatório
              </mat-error>
              <mat-error *ngIf="donationForm.get('amount')?.hasError('min')">
                Valor mínimo é R$ 5,00
              </mat-error>
            </mat-form-field>
          </div>

          <div class="payment-section">
            <h4>Método de Pagamento</h4>
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Selecione o método</mat-label>
              <mat-select formControlName="paymentMethod">
                <mat-option *ngFor="let method of paymentMethods" [value]="method">
                  {{ method }}
                </mat-option>
              </mat-select>
              <mat-icon matSuffix>payment</mat-icon>
              <mat-error *ngIf="donationForm.get('paymentMethod')?.hasError('required')">
                Método de pagamento é obrigatório
              </mat-error>
            </mat-form-field>
          </div>

          <div class="donor-section">
            <h4>Informações do Doador (Opcional)</h4>
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Nome completo</mat-label>
              <input matInput formControlName="donorName" placeholder="Seu nome">
              <mat-icon matSuffix>person</mat-icon>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Email</mat-label>
              <input matInput 
                     type="email" 
                     formControlName="donorEmail" 
                     placeholder="seu@email.com">
              <mat-icon matSuffix>email</mat-icon>
              <mat-error *ngIf="donationForm.get('donorEmail')?.hasError('email')">
                Email deve ser válido
              </mat-error>
            </mat-form-field>
          </div>

          <div class="donation-summary">
            <h4>Resumo da Doação</h4>
            <div class="summary-item">
              <span>Campanha:</span>
              <span>{{ campaign.title }}</span>
            </div>
            <div class="summary-item">
              <span>Valor:</span>
              <span class="amount">R$ {{ (donationForm.get('amount')?.value || 0) | number:'1.2-2' }}</span>
            </div>
            <div class="summary-item" *ngIf="donationForm.get('paymentMethod')?.value">
              <span>Método:</span>
              <span>{{ donationForm.get('paymentMethod')?.value }}</span>
            </div>
          </div>
        </form>
      </mat-dialog-content>

      <mat-dialog-actions>
        <button mat-button mat-dialog-close>Cancelar</button>
        <button mat-raised-button 
                color="primary" 
                (click)="onSubmit()"
                [disabled]="donationForm.invalid || isLoading">
          <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
          <mat-icon *ngIf="!isLoading">favorite</mat-icon>
          <span *ngIf="!isLoading">Confirmar Doação</span>
        </button>
      </mat-dialog-actions>
    </div>
  `,
  styles: [`
    .donation-modal {
      max-width: 500px;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .modal-header h2 {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0;
      color: var(--text-dark);
    }

    .modal-header mat-icon {
      color: var(--primary-green);
    }

    .campaign-info {
      background: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 24px;
    }

    .campaign-info h3 {
      margin: 0 0 12px 0;
      color: var(--text-dark);
      font-size: 16px;
    }

    .progress-bar {
      width: 100%;
      height: 6px;
      background: #e0e0e0;
      border-radius: 3px;
      overflow: hidden;
      margin-bottom: 8px;
    }

    .progress-fill {
      height: 100%;
      background: var(--primary-green);
      transition: width 0.3s ease;
    }

    .progress-text {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: var(--text-light);
    }

    .percentage {
      color: var(--primary-green);
      font-weight: 500;
    }

    .amount-section,
    .payment-section,
    .donor-section {
      margin-bottom: 24px;
    }

    .amount-section h4,
    .payment-section h4,
    .donor-section h4 {
      margin: 0 0 16px 0;
      color: var(--text-dark);
      font-size: 14px;
      font-weight: 500;
    }

    .quick-amounts {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      margin-bottom: 16px;
    }

    .quick-amounts button {
      padding: 8px 16px;
      font-size: 14px;
    }

    .quick-amounts button.selected {
      background: var(--primary-green);
      color: white;
      border-color: var(--primary-green);
    }

    .full-width {
      width: 100%;
    }

    .donation-summary {
      background: #f8f9fa;
      padding: 16px;
      border-radius: 8px;
      margin-top: 24px;
    }

    .donation-summary h4 {
      margin: 0 0 12px 0;
      color: var(--text-dark);
      font-size: 14px;
      font-weight: 500;
    }

    .summary-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
      font-size: 14px;
    }

    .summary-item span:first-child {
      color: var(--text-light);
    }

    .summary-item span:last-child {
      color: var(--text-dark);
      font-weight: 500;
    }

    .summary-item .amount {
      color: var(--primary-green);
      font-weight: 600;
    }

    mat-dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
      margin-top: 24px;
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 480px) {
      .quick-amounts {
        grid-template-columns: repeat(2, 1fr);
      }
    }
  `]
})
export class DonationModalComponent implements OnInit {
  donationForm: FormGroup;
  isLoading = false;
  quickAmounts = [25, 50, 100, 200, 500, 1000];
  paymentMethods: string[] = [];

  constructor(
    private fb: FormBuilder,
    private donationsService: DonationsService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<DonationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { campaign: Campaign }
  ) {
    this.donationForm = this.fb.group({
      amount: ['', [Validators.required, Validators.min(5)]],
      paymentMethod: ['', [Validators.required]],
      donorName: [''],
      donorEmail: ['', [Validators.email]]
    });
  }

  get campaign(): Campaign {
    return this.data.campaign;
  }

  ngOnInit() {
    this.loadPaymentMethods();
  }

  loadPaymentMethods() {
    this.donationsService.getPaymentMethods().subscribe(methods => {
      this.paymentMethods = methods;
    });
  }

  selectAmount(amount: number) {
    this.donationForm.patchValue({ amount });
  }

  getProgressPercentage(): number {
    return Math.min(Math.round((this.campaign.currentAmount / this.campaign.targetAmount) * 100), 100);
  }

  onSubmit() {
    if (this.donationForm.valid) {
      this.isLoading = true;

      const donationData = {
        campaignId: this.campaign.id,
        amount: this.donationForm.value.amount,
        paymentMethod: this.donationForm.value.paymentMethod,
        donorName: this.donationForm.value.donorName,
        donorEmail: this.donationForm.value.donorEmail
      };

      this.donationsService.makeDonation(donationData).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 5000,
              panelClass: ['success-snackbar']
            });
            this.dialogRef.close(true);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao processar doação. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}