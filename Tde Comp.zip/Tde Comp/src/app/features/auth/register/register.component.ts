import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="card-container">
          <mat-card class="register-card">
            <mat-card-header class="text-center">
              <mat-card-title>
                <mat-icon class="register-icon">person_add</mat-icon>
                <h2>Criar Conta</h2>
              </mat-card-title>
              <mat-card-subtitle>
                Cadastre-se para acompanhar campanhas e fazer doações
              </mat-card-subtitle>
            </mat-card-header>

            <mat-card-content>
              <form [formGroup]="registerForm" (ngSubmit)="onSubmit()">
                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Nome Completo</mat-label>
                  <input matInput
                         type="text"
                         formControlName="name"
                         placeholder="Seu nome completo"
                         autocomplete="name">
                  <mat-icon matSuffix>person</mat-icon>
                  <mat-error *ngIf="registerForm.get('name')?.hasError('required')">
                    Nome é obrigatório
                  </mat-error>
                  <mat-error *ngIf="registerForm.get('name')?.hasError('minlength')">
                    Nome deve ter pelo menos 3 caracteres
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>CPF</mat-label>
                  <input matInput
                         type="text"
                         formControlName="cpf"
                         placeholder="000.000.000-00"
                         maxlength="14"
                         (input)="formatCpf($event)">
                  <mat-icon matSuffix>badge</mat-icon>
                  <mat-error *ngIf="registerForm.get('cpf')?.hasError('required')">
                    CPF é obrigatório
                  </mat-error>
                  <mat-error *ngIf="registerForm.get('cpf')?.hasError('invalidCpf')">
                    CPF inválido
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Email</mat-label>
                  <input matInput
                         type="email"
                         formControlName="email"
                         placeholder="seu@email.com"
                         autocomplete="username">
                  <mat-icon matSuffix>email</mat-icon>
                  <mat-error *ngIf="registerForm.get('email')?.hasError('required')">
                    Email é obrigatório
                  </mat-error>
                  <mat-error *ngIf="registerForm.get('email')?.hasError('email')">
                    Email deve ser válido
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Senha</mat-label>
                  <input matInput
                         [type]="hidePassword ? 'password' : 'text'"
                         formControlName="password"
                         placeholder="Mínimo 6 caracteres"
                         autocomplete="new-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hidePassword = !hidePassword"
                          [attr.aria-label]="'Hide password'"
                          [attr.aria-pressed]="hidePassword">
                    <mat-icon>{{hidePassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="registerForm.get('password')?.hasError('required')">
                    Senha é obrigatória
                  </mat-error>
                  <mat-error *ngIf="registerForm.get('password')?.hasError('minlength')">
                    Senha deve ter pelo menos 6 caracteres
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Confirmar Senha</mat-label>
                  <input matInput
                         [type]="hideConfirmPassword ? 'password' : 'text'"
                         formControlName="confirmPassword"
                         placeholder="Digite a senha novamente"
                         autocomplete="new-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hideConfirmPassword = !hideConfirmPassword"
                          [attr.aria-label]="'Hide password'"
                          [attr.aria-pressed]="hideConfirmPassword">
                    <mat-icon>{{hideConfirmPassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="registerForm.get('confirmPassword')?.hasError('required')">
                    Confirmação de senha é obrigatória
                  </mat-error>
                  <mat-error *ngIf="registerForm.hasError('passwordMismatch') && !registerForm.get('confirmPassword')?.hasError('required')">
                    Senhas não coincidem
                  </mat-error>
                </mat-form-field>

                <div class="cpf-info">
                  <mat-icon>info</mat-icon>
                  <p>O CPF é obrigatório para realizar doações e garantir a transparência das transações.</p>
                </div>

                <button mat-raised-button
                        color="primary"
                        type="submit"
                        class="full-width register-button"
                        [disabled]="registerForm.invalid || isLoading">
                  <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
                  <span *ngIf="!isLoading">Criar Conta</span>
                </button>
              </form>
            </mat-card-content>

            <mat-card-actions class="text-center">
              <p>Já possui uma conta?</p>
              <a mat-button color="primary" routerLink="/login">
                Fazer login
              </a>
            </mat-card-actions>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-card {
      max-width: 100%;
      margin: 0;
    }

    .register-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: var(--primary-green);
      margin-bottom: 16px;
    }

    mat-card-header {
      margin-bottom: 24px;
    }

    mat-card-title h2 {
      margin: 0;
      color: var(--text-dark);
    }

    mat-card-subtitle {
      color: var(--text-light);
      margin-top: 8px;
    }

    mat-form-field {
      margin-bottom: 16px;
    }

    .cpf-info {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      background: #e3f2fd;
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 24px;
    }

    .cpf-info mat-icon {
      color: var(--primary-blue);
      font-size: 20px;
      margin-top: 2px;
    }

    .cpf-info p {
      margin: 0;
      font-size: 14px;
      color: var(--text-dark);
      line-height: 1.4;
    }

    .register-button {
      margin-bottom: 24px;
      height: 48px;
      font-size: 16px;
    }

    mat-card-actions {
      padding-top: 16px;
      border-top: 1px solid #e0e0e0;
    }

    mat-card-actions p {
      margin: 0 0 8px 0;
      color: var(--text-light);
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 480px) {
      .card-container {
        padding: 0 8px;
      }
    }
  `]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  hidePassword = true;
  hideConfirmPassword = true;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      cpf: ['', [Validators.required, this.cpfValidator.bind(this)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit() {
    // Check if user is already logged in
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
    }
  }

  cpfValidator(control: AbstractControl): { [key: string]: any } | null {
    if (!control.value) return null;
    
    const isValid = this.authService.validateCpf(control.value);
    return isValid ? null : { invalidCpf: true };
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');
    
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { passwordMismatch: true };
    }
    return null;
  }

  formatCpf(event: any) {
    let value = event.target.value.replace(/\D/g, '');
    
    if (value.length <= 11) {
      value = value.replace(/(\d{3})(\d)/, '$1.$2');
      value = value.replace(/(\d{3})(\d)/, '$1.$2');
      value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }
    
    event.target.value = value;
    this.registerForm.patchValue({ cpf: value });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      this.isLoading = true;
      
      this.authService.register(this.registerForm.value).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.router.navigate(['/']);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao criar conta. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}