import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="card-container">
          <mat-card class="change-password-card">
            <mat-card-header class="text-center">
              <mat-card-title>
                <mat-icon class="lock-icon">lock_reset</mat-icon>
                <h2>Alterar Senha</h2>
              </mat-card-title>
              <mat-card-subtitle>
                Digite sua senha atual e escolha uma nova senha
              </mat-card-subtitle>
            </mat-card-header>

            <mat-card-content>
              <form [formGroup]="changePasswordForm" (ngSubmit)="onSubmit()">
                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Senha Atual</mat-label>
                  <input matInput
                         [type]="hideCurrentPassword ? 'password' : 'text'"
                         formControlName="currentPassword"
                         placeholder="Digite sua senha atual"
                         autocomplete="current-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hideCurrentPassword = !hideCurrentPassword"
                          [attr.aria-label]="'Toggle password visibility'">
                    <mat-icon>{{hideCurrentPassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="changePasswordForm.get('currentPassword')?.hasError('required')">
                    Senha atual é obrigatória
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Nova Senha</mat-label>
                  <input matInput
                         [type]="hideNewPassword ? 'password' : 'text'"
                         formControlName="newPassword"
                         placeholder="Mínimo 6 caracteres"
                         autocomplete="new-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hideNewPassword = !hideNewPassword"
                          [attr.aria-label]="'Toggle password visibility'">
                    <mat-icon>{{hideNewPassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="changePasswordForm.get('newPassword')?.hasError('required')">
                    Nova senha é obrigatória
                  </mat-error>
                  <mat-error *ngIf="changePasswordForm.get('newPassword')?.hasError('minlength')">
                    Nova senha deve ter pelo menos 6 caracteres
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Confirmar Nova Senha</mat-label>
                  <input matInput
                         [type]="hideConfirmPassword ? 'password' : 'text'"
                         formControlName="confirmNewPassword"
                         placeholder="Digite a nova senha novamente"
                         autocomplete="new-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hideConfirmPassword = !hideConfirmPassword"
                          [attr.aria-label]="'Toggle password visibility'">
                    <mat-icon>{{hideConfirmPassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="changePasswordForm.get('confirmNewPassword')?.hasError('required')">
                    Confirmação de senha é obrigatória
                  </mat-error>
                  <mat-error *ngIf="changePasswordForm.hasError('passwordMismatch') && !changePasswordForm.get('confirmNewPassword')?.hasError('required')">
                    Senhas não coincidem
                  </mat-error>
                </mat-form-field>

                <div class="security-tips">
                  <h4>Dicas de Segurança:</h4>
                  <ul>
                    <li>Use pelo menos 8 caracteres</li>
                    <li>Combine letras maiúsculas e minúsculas</li>
                    <li>Inclua números e símbolos</li>
                    <li>Evite informações pessoais</li>
                  </ul>
                </div>

                <div class="form-actions">
                  <button mat-button type="button" routerLink="/perfil">
                    Cancelar
                  </button>
                  <button mat-raised-button
                          color="primary"
                          type="submit"
                          [disabled]="changePasswordForm.invalid || isLoading">
                    <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
                    <span *ngIf="!isLoading">Alterar Senha</span>
                  </button>
                </div>
              </form>
            </mat-card-content>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .change-password-card {
      max-width: 100%;
      margin: 0;
    }

    .lock-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: var(--warning);
      margin-bottom: 16px;
    }

    mat-card-header {
      margin-bottom: 24px;
    }

    mat-card-title h2 {
      margin: 0;
      color: var(--text-dark);
    }

    mat-card-subtitle {
      color: var(--text-light);
      margin-top: 8px;
    }

    mat-form-field {
      margin-bottom: 16px;
    }

    .security-tips {
      background: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin: 24px 0;
    }

    .security-tips h4 {
      margin: 0 0 12px 0;
      color: var(--primary-blue);
    }

    .security-tips ul {
      margin: 0;
      padding-left: 20px;
    }

    .security-tips li {
      margin-bottom: 4px;
      font-size: 14px;
      color: var(--text-light);
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 16px;
      margin-top: 24px;
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 480px) {
      .card-container {
        padding: 0 8px;
      }

      .form-actions {
        flex-direction: column-reverse;
        gap: 8px;
      }
    }
  `]
})
export class ChangePasswordComponent {
  changePasswordForm: FormGroup;
  hideCurrentPassword = true;
  hideNewPassword = true;
  hideConfirmPassword = true;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.changePasswordForm = this.fb.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmNewPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword');
    const confirmNewPassword = form.get('confirmNewPassword');
    
    if (newPassword && confirmNewPassword && newPassword.value !== confirmNewPassword.value) {
      return { passwordMismatch: true };
    }
    return null;
  }

  onSubmit() {
    if (this.changePasswordForm.valid) {
      this.isLoading = true;
      
      const { currentPassword, newPassword } = this.changePasswordForm.value;
      
      this.authService.changePassword(currentPassword, newPassword).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.router.navigate(['/perfil']);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao alterar senha. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}