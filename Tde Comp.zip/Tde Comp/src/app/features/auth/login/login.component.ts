import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="card-container">
          <mat-card class="login-card">
            <mat-card-header class="text-center">
              <mat-card-title>
                <mat-icon class="login-icon">lock</mat-icon>
                <h2>Entrar na Plataforma</h2>
              </mat-card-title>
              <mat-card-subtitle>
                Acesse sua conta para gerenciar campanhas e doações
              </mat-card-subtitle>
            </mat-card-header>

            <mat-card-content>
              <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Email</mat-label>
                  <input matInput
                         type="email"
                         formControlName="email"
                         placeholder="seu@email.com"
                         autocomplete="username">
                  <mat-icon matSuffix>email</mat-icon>
                  <mat-error *ngIf="loginForm.get('email')?.hasError('required')">
                    Email é obrigatório
                  </mat-error>
                  <mat-error *ngIf="loginForm.get('email')?.hasError('email')">
                    Email deve ser válido
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Senha</mat-label>
                  <input matInput
                         [type]="hidePassword ? 'password' : 'text'"
                         formControlName="password"
                         placeholder="Sua senha"
                         autocomplete="current-password">
                  <button mat-icon-button
                          matSuffix
                          type="button"
                          (click)="hidePassword = !hidePassword"
                          [attr.aria-label]="'Hide password'"
                          [attr.aria-pressed]="hidePassword">
                    <mat-icon>{{hidePassword ? 'visibility_off' : 'visibility'}}</mat-icon>
                  </button>
                  <mat-error *ngIf="loginForm.get('password')?.hasError('required')">
                    Senha é obrigatória
                  </mat-error>
                  <mat-error *ngIf="loginForm.get('password')?.hasError('minlength')">
                    Senha deve ter pelo menos 6 caracteres
                  </mat-error>
                </mat-form-field>

                <div class="forgot-password-link">
                  <a routerLink="/esqueci-senha">Esqueci minha senha</a>
                </div>

                <button mat-raised-button
                        color="primary"
                        type="submit"
                        class="full-width login-button"
                        [disabled]="loginForm.invalid || isLoading">
                  @if (isLoading) {
                    <mat-spinner diameter="20"></mat-spinner>
                  } @else {
                    <span>Entrar</span>
                  }
                </button>
              </form>

              <div class="demo-credentials">
                <p><strong>Credenciais de demonstração:</strong></p>
                <p>Email: joao&#64;exemplo.com</p>
                <p>Senha: 123456</p>
              </div>
            </mat-card-content>

            <mat-card-actions class="text-center">
              <p>Não possui uma conta?</p>
              <a mat-button color="primary" routerLink="/cadastro">
                Criar conta gratuita
              </a>
            </mat-card-actions>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-card {
      max-width: 100%;
      margin: 0;
    }

    .login-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: var(--primary-blue);
      margin-bottom: 16px;
    }

    mat-card-header {
      margin-bottom: 24px;
    }

    mat-card-title h2 {
      margin: 0;
      color: var(--text-dark);
    }

    mat-card-subtitle {
      color: var(--text-light);
      margin-top: 8px;
    }

    mat-form-field {
      margin-bottom: 16px;
    }

    .forgot-password-link {
      text-align: right;
      margin-bottom: 24px;
    }

    .forgot-password-link a {
      color: var(--primary-blue);
      text-decoration: none;
      font-size: 14px;
    }

    .forgot-password-link a:hover {
      text-decoration: underline;
    }

    .login-button {
      margin-bottom: 24px;
      height: 48px;
      font-size: 16px;
    }

    .demo-credentials {
      background: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin: 24px 0;
      font-size: 14px;
    }

    .demo-credentials p {
      margin: 4px 0;
    }

    .demo-credentials strong {
      color: var(--primary-blue);
    }

    mat-card-actions {
      padding-top: 16px;
      border-top: 1px solid #e0e0e0;
    }

    mat-card-actions p {
      margin: 0 0 8px 0;
      color: var(--text-light);
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 480px) {
      .card-container {
        padding: 0 8px;
      }
    }
  `]
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  hidePassword = true;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
    // Check if user is already logged in
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/']);
    }
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.isLoading = true;
      
      this.authService.login(this.loginForm.value).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.router.navigate(['/']);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao realizar login. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}