import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AdminService } from '../../../../core/services/admin.service';
import { AdminCampaign } from '../admin-campaigns.component';

@Component({
  selector: 'app-edit-campaign-admin-modal',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  templateUrl: './edit-campaign-admin-modal.component.html',
  styleUrls: ['./edit-campaign-admin-modal.component.css']
})
export class EditCampaignAdminModalComponent implements OnInit {
  editForm: FormGroup;
  isLoading = false;
  minDate = new Date();
  maxDate = new Date(new Date().setFullYear(new Date().getFullYear() + 2));
  originalFormValue: any;

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<EditCampaignAdminModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { campaign: AdminCampaign }
  ) {
    this.editForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(10)]],
      description: ['', [Validators.required, Validators.minLength(50)]],
      targetAmount: ['', [Validators.required, Validators.min(100)]],
      endDate: ['', [Validators.required]],
      imageUrl: ['', [Validators.pattern(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)]]
    });
  }

  get campaign(): AdminCampaign {
    return this.data.campaign;
  }

  ngOnInit() {
    // Populate form with current campaign data
    this.editForm.patchValue({
      title: this.campaign.title,
      description: this.campaign.description,
      targetAmount: this.campaign.targetAmount,
      endDate: new Date(this.campaign.endDate),
      imageUrl: this.campaign.imageUrl
    });
    
    this.originalFormValue = this.editForm.value;
  }

  hasChanges(): boolean {
    return JSON.stringify(this.editForm.value) !== JSON.stringify(this.originalFormValue);
  }

  onSubmit() {
    if (this.editForm.valid && this.hasChanges()) {
      this.isLoading = true;
      
      const updateData = { ...this.editForm.value };
      
      // Format date for backend
      if (updateData.endDate instanceof Date) {
        updateData.endDate = updateData.endDate.toISOString().split('T')[0];
      }
      
      this.adminService.updateCampaignAdmin(this.campaign.id, updateData).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.dialogRef.close(true);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao atualizar campanha. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}