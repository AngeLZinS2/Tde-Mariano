import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { AdminService } from '../../../core/services/admin.service';
import { EditCampaignAdminModalComponent } from './edit-campaign-admin-modal/edit-campaign-admin-modal.component';

export interface AdminCampaign {
  id: number;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  endDate: string;
  imageUrl: string;
  isActive: boolean;
  isApproved: boolean;
  approvalDate?: string;
  createdBy: string;
  approvedBy?: string;
  createdAt: string;
  donationsCount: number;
}

@Component({
  selector: 'app-admin-campaigns',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatChipsModule,
    MatSnackBarModule,
    MatDialogModule
  ],
  templateUrl: './admin-campaigns.component.html',
  styleUrls: ['./admin-campaigns.component.css']
})
export class AdminCampaignsComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  displayedColumns: string[] = ['campaign', 'status', 'progress', 'stats', 'actions'];
  dataSource = new MatTableDataSource<AdminCampaign>();
  isLoading = true;
  totalCampaigns = 0;

  constructor(
    private adminService: AdminService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadCampaigns();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  loadCampaigns() {
    this.isLoading = true;
    
    this.adminService.getAllCampaigns().subscribe({
      next: (campaigns) => {
        this.dataSource.data = campaigns;
        this.totalCampaigns = campaigns.length;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Erro ao carregar campanhas', 'Fechar', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  getProgressPercentage(campaign: AdminCampaign): number {
    return Math.min(Math.round((campaign.currentAmount / campaign.targetAmount) * 100), 100);
  }

  toggleApproval(campaign: AdminCampaign) {
    const action = campaign.isApproved ? 'rejeitar' : 'aprovar';
    
    this.adminService.toggleCampaignApproval(campaign.id).subscribe({
      next: (result) => {
        if (result.success) {
          this.snackBar.open(result.message, 'Fechar', {
            duration: 3000,
            panelClass: ['success-snackbar']
          });
          this.loadCampaigns();
        } else {
          this.snackBar.open(result.message, 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      },
      error: () => {
        this.snackBar.open(`Erro ao ${action} campanha. Tente novamente.`, 'Fechar', {
          duration: 4000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  editCampaign(campaign: AdminCampaign) {
    const dialogRef = this.dialog.open(EditCampaignAdminModalComponent, {
      width: '600px',
      data: { campaign }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadCampaigns();
      }
    });
  }

  deleteCampaign(campaign: AdminCampaign) {
    if (campaign.donationsCount > 0) {
      this.snackBar.open('Não é possível excluir campanha que já recebeu doações', 'Fechar', {
        duration: 4000,
        panelClass: ['error-snackbar']
      });
      return;
    }

    if (confirm(`Tem certeza que deseja excluir a campanha "${campaign.title}"? Esta ação não pode ser desfeita.`)) {
      this.adminService.deleteCampaign(campaign.id).subscribe({
        next: (result) => {
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.loadCampaigns();
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.snackBar.open('Erro ao excluir campanha. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }

  viewDetails(campaign: AdminCampaign) {
    // In a real application, this would navigate to a campaign details page
    console.log('Viewing details for campaign:', campaign);
  }

  onImageError(event: any) {
    event.target.src = 'https://images.pexels.com/photos/6647100/pexels-photo-6647100.jpeg?auto=compress&cs=tinysrgb&w=800';
  }
}