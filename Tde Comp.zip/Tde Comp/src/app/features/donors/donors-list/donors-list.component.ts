import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DonorsService, Donor } from '../../../core/services/donors.service';

@Component({
  selector: 'app-donors-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatFormFieldModule,
    MatTooltipModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="page-header">
          <h1>
            <mat-icon>people</mat-icon>
            Lista de Doadores
          </h1>
          <p>Visualize e gerencie os doadores cadastrados na plataforma</p>
        </div>

        <mat-card class="donors-card">
          <mat-card-header>
            <div class="card-header-content">
              <div class="card-title">
                <mat-card-title>Doadores Cadastrados</mat-card-title>
                <mat-card-subtitle>Total de {{ totalDonors }} doadores</mat-card-subtitle>
              </div>
              
              <div class="filter-section">
                <mat-form-field appearance="outline">
                  <mat-label>Buscar doador</mat-label>
                  <input matInput
                         (keyup)="applyFilter($event)"
                         placeholder="Nome ou email"
                         #input>
                  <mat-icon matSuffix>search</mat-icon>
                </mat-form-field>
              </div>
            </div>
          </mat-card-header>

          <mat-card-content>
            <div *ngIf="isLoading" class="loading-spinner">
              <mat-spinner></mat-spinner>
              <p>Carregando doadores...</p>
            </div>

            <div *ngIf="!isLoading" class="table-container">
              <table mat-table [dataSource]="dataSource" class="donors-table">
                <!-- Name Column -->
                <ng-container matColumnDef="name">
                  <th mat-header-cell *matHeaderCellDef>Nome</th>
                  <td mat-cell *matCellDef="let donor" class="name-cell">
                    <div class="donor-info">
                      <div class="avatar">
                        <mat-icon>account_circle</mat-icon>
                      </div>
                      <div class="donor-details">
                        <div class="donor-name">{{ donor.name }}</div>
                        <div class="donor-email">{{ donor.email }}</div>
                      </div>
                    </div>
                  </td>
                </ng-container>

                <!-- Last Donation Date Column -->
                <ng-container matColumnDef="lastDonationDate">
                  <th mat-header-cell *matHeaderCellDef>Última Doação</th>
                  <td mat-cell *matCellDef="let donor">
                    <div class="date-cell">
                      <mat-icon class="date-icon">event</mat-icon>
                      {{ donor.lastDonationDate | date:'dd/MM/yyyy' }}
                    </div>
                  </td>
                </ng-container>

                <!-- Total Donated Column -->
                <ng-container matColumnDef="totalDonated">
                  <th mat-header-cell *matHeaderCellDef>Total Doado</th>
                  <td mat-cell *matCellDef="let donor" class="amount-cell">
                    <div class="amount-container">
                      <span class="currency">R$</span>
                      <span class="amount">{{ donor.totalDonated | number:'1.2-2' }}</span>
                    </div>
                  </td>
                </ng-container>

                <!-- Donations Count Column -->
                <ng-container matColumnDef="donationsCount">
                  <th mat-header-cell *matHeaderCellDef>Nº Doações</th>
                  <td mat-cell *matCellDef="let donor" class="count-cell">
                    <div class="count-badge">
                      {{ donor.donationsCount }}
                    </div>
                  </td>
                </ng-container>

                <!-- Actions Column -->
                <ng-container matColumnDef="actions">
                  <th mat-header-cell *matHeaderCellDef>Ações</th>
                  <td mat-cell *matCellDef="let donor">
                    <div class="actions-cell">
                      <button mat-icon-button
                              [matTooltip]="'Ver detalhes de ' + donor.name"
                              (click)="viewDonorDetails(donor)">
                        <mat-icon>visibility</mat-icon>
                      </button>
                      <button mat-icon-button
                              [matTooltip]="'Enviar mensagem para ' + donor.name"
                              (click)="sendMessage(donor)">
                        <mat-icon>mail</mat-icon>
                      </button>
                    </div>
                  </td>
                </ng-container>

                <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="donor-row"></tr>
              </table>

              <mat-paginator #paginator
                           [length]="totalDonors"
                           [pageSize]="10"
                           [pageSizeOptions]="[5, 10, 25, 50]"
                           aria-label="Selecionar página de doadores">
              </mat-paginator>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .page-header {
      text-align: center;
      margin-bottom: 2rem;
    }

    .page-header h1 {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .page-header h1 mat-icon {
      font-size: 32px;
      color: var(--primary-blue);
    }

    .page-header p {
      color: var(--text-light);
      margin: 0;
    }

    .donors-card {
      margin-bottom: 2rem;
    }

    .card-header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
    }

    .card-title {
      flex: 1;
    }

    .filter-section {
      max-width: 300px;
    }

    .filter-section mat-form-field {
      width: 100%;
    }

    .table-container {
      margin-top: 1rem;
    }

    .donors-table {
      width: 100%;
    }

    .donor-row {
      transition: background-color 0.2s;
    }

    .donor-row:hover {
      background-color: #f5f5f5;
    }

    .name-cell {
      min-width: 250px;
    }

    .donor-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: var(--primary-blue);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }

    .avatar mat-icon {
      font-size: 24px;
    }

    .donor-details {
      flex: 1;
    }

    .donor-name {
      font-weight: 500;
      color: var(--text-dark);
    }

    .donor-email {
      font-size: 12px;
      color: var(--text-light);
      margin-top: 2px;
    }

    .date-cell {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .date-icon {
      font-size: 18px;
      color: var(--text-light);
    }

    .amount-cell {
      font-family: 'Roboto Mono', monospace;
    }

    .amount-container {
      display: flex;
      align-items: baseline;
      gap: 4px;
    }

    .currency {
      font-size: 12px;
      color: var(--text-light);
    }

    .amount {
      font-weight: 500;
      color: var(--primary-green);
      font-size: 14px;
    }

    .count-cell {
      text-align: center;
    }

    .count-badge {
      display: inline-block;
      background: var(--primary-blue);
      color: white;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
      min-width: 24px;
    }

    .actions-cell {
      display: flex;
      gap: 4px;
    }

    .actions-cell button {
      color: var(--text-light);
    }

    .actions-cell button:hover {
      color: var(--primary-blue);
    }

    .loading-spinner {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2rem;
    }

    .loading-spinner p {
      margin-top: 1rem;
      color: var(--text-light);
    }

    @media (max-width: 768px) {
      .card-header-content {
        flex-direction: column;
        gap: 16px;
        align-items: stretch;
      }

      .filter-section {
        max-width: none;
      }

      .table-container {
        overflow-x: auto;
      }

      .donors-table {
        min-width: 600px;
      }

      .name-cell {
        min-width: 200px;
      }

      .donor-info {
        gap: 8px;
      }

      .avatar {
        width: 32px;
        height: 32px;
      }

      .avatar mat-icon {
        font-size: 20px;
      }
    }
  `]
})
export class DonorsListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  displayedColumns: string[] = ['name', 'lastDonationDate', 'totalDonated', 'donationsCount', 'actions'];
  dataSource = new MatTableDataSource<Donor>();
  isLoading = true;
  totalDonors = 0;

  constructor(private donorsService: DonorsService) {}

  ngOnInit() {
    this.loadDonors();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  loadDonors() {
    this.isLoading = true;
    
    this.donorsService.getDonors().subscribe({
      next: (donors) => {
        this.dataSource.data = donors;
        this.totalDonors = donors.length;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  viewDonorDetails(donor: Donor) {
    // In a real application, this would navigate to a donor details page
    console.log('Viewing details for donor:', donor);
  }

  sendMessage(donor: Donor) {
    // In a real application, this would open a message composition modal
    console.log('Sending message to donor:', donor);
  }
}