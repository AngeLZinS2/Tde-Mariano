import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { CampaignsService } from '../../../core/services/campaigns.service';

@Component({
  selector: 'app-create-campaign',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="page-header">
          <h1>
            <mat-icon>add_circle</mat-icon>
            Criar Nova Campanha
          </h1>
          <p>Preencha as informações abaixo para criar uma nova campanha de arrecadação</p>
        </div>

        <div class="form-container">
          <mat-card class="campaign-form-card">
            <mat-card-content>
              <form [formGroup]="campaignForm" (ngSubmit)="onSubmit()">
                <div class="form-row">
                  <mat-form-field appearance="outline" class="full-width">
                    <mat-label>Título da Campanha</mat-label>
                    <input matInput
                           formControlName="title"
                           placeholder="Ex: Alimentação para Famílias Carentes"
                           maxlength="100">
                    <mat-icon matSuffix>title</mat-icon>
                    <mat-hint>{{ campaignForm.get('title')?.value?.length || 0 }}/100 caracteres</mat-hint>
                    <mat-error *ngIf="campaignForm.get('title')?.hasError('required')">
                      Título é obrigatório
                    </mat-error>
                    <mat-error *ngIf="campaignForm.get('title')?.hasError('minlength')">
                      Título deve ter pelo menos 10 caracteres
                    </mat-error>
                  </mat-form-field>
                </div>

                <div class="form-row">
                  <mat-form-field appearance="outline" class="full-width">
                    <mat-label>Descrição da Campanha</mat-label>
                    <textarea matInput
                              formControlName="description"
                              placeholder="Descreva detalhadamente o objetivo da campanha, como os recursos serão utilizados e o impacto esperado..."
                              rows="6"
                              maxlength="1000"></textarea>
                    <mat-icon matSuffix>description</mat-icon>
                    <mat-hint>{{ campaignForm.get('description')?.value?.length || 0 }}/1000 caracteres</mat-hint>
                    <mat-error *ngIf="campaignForm.get('description')?.hasError('required')">
                      Descrição é obrigatória
                    </mat-error>
                    <mat-error *ngIf="campaignForm.get('description')?.hasError('minlength')">
                      Descrição deve ter pelo menos 50 caracteres
                    </mat-error>
                  </mat-form-field>
                </div>

                <div class="form-row">
                  <div class="form-grid">
                    <mat-form-field appearance="outline">
                      <mat-label>Meta Financeira</mat-label>
                      <input matInput
                             type="number"
                             formControlName="targetAmount"
                             placeholder="0,00"
                             min="100"
                             step="0.01">
                      <span matTextPrefix>R$ </span>
                      <mat-icon matSuffix>monetization_on</mat-icon>
                      <mat-error *ngIf="campaignForm.get('targetAmount')?.hasError('required')">
                        Meta financeira é obrigatória
                      </mat-error>
                      <mat-error *ngIf="campaignForm.get('targetAmount')?.hasError('min')">
                        Meta deve ser de pelo menos R$ 100,00
                      </mat-error>
                    </mat-form-field>

                    <mat-form-field appearance="outline">
                      <mat-label>Data de Encerramento</mat-label>
                      <input matInput
                             [matDatepicker]="picker"
                             formControlName="endDate"
                             [min]="minDate"
                             [max]="maxDate">
                      <mat-datepicker-toggle matIconSuffix [for]="picker"></mat-datepicker-toggle>
                      <mat-datepicker #picker></mat-datepicker>
                      <mat-error *ngIf="campaignForm.get('endDate')?.hasError('required')">
                        Data de encerramento é obrigatória
                      </mat-error>
                    </mat-form-field>
                  </div>
                </div>

                <div class="form-row">
                  <mat-form-field appearance="outline" class="full-width">
                    <mat-label>URL da Imagem (opcional)</mat-label>
                    <input matInput
                           formControlName="imageUrl"
                           placeholder="https://exemplo.com/imagem.jpg"
                           type="url">
                    <mat-icon matSuffix>image</mat-icon>
                    <mat-hint>Deixe em branco para usar uma imagem padrão</mat-hint>
                    <mat-error *ngIf="campaignForm.get('imageUrl')?.hasError('pattern')">
                      URL da imagem deve ser válida
                    </mat-error>
                  </mat-form-field>
                </div>

                <div class="preview-section" *ngIf="campaignForm.get('title')?.value && campaignForm.get('description')?.value">
                  <h3>Pré-visualização da Campanha</h3>
                  <mat-card class="campaign-preview">
                    <div class="preview-image">
                      <img [src]="getPreviewImage()" 
                           [alt]="campaignForm.get('title')?.value"
                           (error)="onImageError($event)">
                    </div>
                    <mat-card-content>
                      <h4>{{ campaignForm.get('title')?.value }}</h4>
                      <p class="preview-description">{{ campaignForm.get('description')?.value }}</p>
                      <div class="preview-details" *ngIf="campaignForm.get('targetAmount')?.value">
                        <div class="preview-meta">
                          <strong>Meta:</strong> R$ {{ campaignForm.get('targetAmount')?.value | number:'1.2-2' }}
                        </div>
                        <div class="preview-meta" *ngIf="campaignForm.get('endDate')?.value">
                          <strong>Encerra em:</strong> {{ campaignForm.get('endDate')?.value | date:'dd/MM/yyyy' }}
                        </div>
                      </div>
                    </mat-card-content>
                  </mat-card>
                </div>

                <div class="form-actions">
                  <button mat-button type="button" routerLink="/doacoes">
                    Cancelar
                  </button>
                  <button mat-raised-button
                          color="primary"
                          type="submit"
                          [disabled]="campaignForm.invalid || isLoading">
                    <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
                    <mat-icon *ngIf="!isLoading">publish</mat-icon>
                    <span *ngIf="!isLoading">Criar Campanha</span>
                  </button>
                </div>
              </form>
            </mat-card-content>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-header {
      text-align: center;
      margin-bottom: 2rem;
    }

    .page-header h1 {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .page-header h1 mat-icon {
      font-size: 32px;
      color: var(--primary-green);
    }

    .page-header p {
      color: var(--text-light);
      margin: 0;
    }

    .form-container {
      max-width: 800px;
      margin: 0 auto;
    }

    .campaign-form-card {
      padding: 0;
    }

    .form-row {
      margin-bottom: 24px;
    }

    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .full-width {
      width: 100%;
    }

    .preview-section {
      margin: 32px 0;
      padding-top: 24px;
      border-top: 1px solid #e0e0e0;
    }

    .preview-section h3 {
      margin: 0 0 16px 0;
      color: var(--primary-blue);
    }

    .campaign-preview {
      max-width: 400px;
      margin: 0 auto;
    }

    .preview-image {
      height: 200px;
      overflow: hidden;
    }

    .preview-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .campaign-preview h4 {
      margin: 0 0 12px 0;
      color: var(--text-dark);
    }

    .preview-description {
      color: var(--text-light);
      font-size: 14px;
      margin-bottom: 16px;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .preview-details {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .preview-meta {
      font-size: 12px;
      color: var(--text-light);
    }

    .preview-meta strong {
      color: var(--text-dark);
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 16px;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid #e0e0e0;
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 768px) {
      .form-grid {
        grid-template-columns: 1fr;
        gap: 0;
      }

      .form-actions {
        flex-direction: column-reverse;
        gap: 8px;
      }

      .campaign-preview {
        max-width: none;
      }
    }
  `]
})
export class CreateCampaignComponent {
  campaignForm: FormGroup;
  isLoading = false;
  minDate = new Date();
  maxDate = new Date(new Date().setFullYear(new Date().getFullYear() + 2));
  
  private defaultImage = 'https://images.pexels.com/photos/6647100/pexels-photo-6647100.jpeg?auto=compress&cs=tinysrgb&w=800';

  constructor(
    private fb: FormBuilder,
    private campaignsService: CampaignsService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.campaignForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(10)]],
      description: ['', [Validators.required, Validators.minLength(50)]],
      targetAmount: ['', [Validators.required, Validators.min(100)]],
      endDate: ['', [Validators.required]],
      imageUrl: ['', [Validators.pattern(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)]]
    });
  }

  onSubmit() {
    if (this.campaignForm.valid) {
      this.isLoading = true;
      
      const formData = { ...this.campaignForm.value };
      
      // Use default image if none provided
      if (!formData.imageUrl) {
        formData.imageUrl = this.defaultImage;
      }
      
      this.campaignsService.createCampaign(formData).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['success-snackbar']
            });
            this.router.navigate(['/doacoes']);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao criar campanha. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }

  getPreviewImage(): string {
    const imageUrl = this.campaignForm.get('imageUrl')?.value;
    return imageUrl || this.defaultImage;
  }

  onImageError(event: any) {
    event.target.src = this.defaultImage;
  }
}