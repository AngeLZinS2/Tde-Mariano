import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Campaign, CampaignsService } from '../../../../core/services/campaigns.service';

@Component({
  selector: 'app-edit-campaign-modal',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  template: `
    <div class="edit-campaign-modal">
      <div class="modal-header">
        <h2 mat-dialog-title>
          <mat-icon>edit</mat-icon>
          Editar Campanha
        </h2>
        <button mat-icon-button mat-dialog-close>
          <mat-icon>close</mat-icon>
        </button>
      </div>

      <mat-dialog-content>
        <form [formGroup]="editForm" (ngSubmit)="onSubmit()">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Título da Campanha</mat-label>
            <input matInput
                   formControlName="title"
                   placeholder="Ex: Alimentação para Famílias Carentes"
                   maxlength="100">
            <mat-icon matSuffix>title</mat-icon>
            <mat-hint>{{ editForm.get('title')?.value?.length || 0 }}/100 caracteres</mat-hint>
            <mat-error *ngIf="editForm.get('title')?.hasError('required')">
              Título é obrigatório
            </mat-error>
            <mat-error *ngIf="editForm.get('title')?.hasError('minlength')">
              Título deve ter pelo menos 10 caracteres
            </mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Descrição da Campanha</mat-label>
            <textarea matInput
                      formControlName="description"
                      placeholder="Descreva detalhadamente o objetivo da campanha..."
                      rows="4"
                      maxlength="1000"></textarea>
            <mat-icon matSuffix>description</mat-icon>
            <mat-hint>{{ editForm.get('description')?.value?.length || 0 }}/1000 caracteres</mat-hint>
            <mat-error *ngIf="editForm.get('description')?.hasError('required')">
              Descrição é obrigatória
            </mat-error>
            <mat-error *ngIf="editForm.get('description')?.hasError('minlength')">
              Descrição deve ter pelo menos 50 caracteres
            </mat-error>
          </mat-form-field>

          <div class="form-row">
            <mat-form-field appearance="outline">
              <mat-label>Meta Financeira</mat-label>
              <input matInput
                     type="number"
                     formControlName="targetAmount"
                     placeholder="0,00"
                     min="100"
                     step="0.01">
              <span matTextPrefix>R$ </span>
              <mat-icon matSuffix>monetization_on</mat-icon>
              <mat-error *ngIf="editForm.get('targetAmount')?.hasError('required')">
                Meta financeira é obrigatória
              </mat-error>
              <mat-error *ngIf="editForm.get('targetAmount')?.hasError('min')">
                Meta deve ser de pelo menos R$ 100,00
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Data de Encerramento</mat-label>
              <input matInput
                     [matDatepicker]="picker"
                     formControlName="endDate"
                     [min]="minDate"
                     [max]="maxDate">
              <mat-datepicker-toggle matIconSuffix [for]="picker"></mat-datepicker-toggle>
              <mat-datepicker #picker></mat-datepicker>
              <mat-error *ngIf="editForm.get('endDate')?.hasError('required')">
                Data de encerramento é obrigatória
              </mat-error>
            </mat-form-field>
          </div>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>URL da Imagem</mat-label>
            <input matInput
                   formControlName="imageUrl"
                   placeholder="https://exemplo.com/imagem.jpg"
                   type="url">
            <mat-icon matSuffix>image</mat-icon>
            <mat-error *ngIf="editForm.get('imageUrl')?.hasError('pattern')">
              URL da imagem deve ser válida
            </mat-error>
          </mat-form-field>

          <div class="campaign-info">
            <h4>Informações da Campanha</h4>
            <div class="info-grid">
              <div class="info-item">
                <span class="label">Valor Arrecadado:</span>
                <span class="value">R$ {{ campaign.currentAmount | number:'1.2-2' }}</span>
              </div>
              <div class="info-item">
                <span class="label">Doações Recebidas:</span>
                <span class="value">{{ campaign.donationsCount || 0 }}</span>
              </div>
              <div class="info-item">
                <span class="label">Status:</span>
                <span class="value" [class.active]="campaign.isActive" [class.inactive]="!campaign.isActive">
                  {{ campaign.isActive ? 'Ativa' : 'Encerrada' }}
                </span>
              </div>
              <div class="info-item">
                <span class="label">Criada em:</span>
                <span class="value">{{ campaign.createdAt | date:'dd/MM/yyyy' }}</span>
              </div>
            </div>
          </div>
        </form>
      </mat-dialog-content>

      <mat-dialog-actions>
        <button mat-button mat-dialog-close>Cancelar</button>
        <button mat-raised-button 
                color="primary" 
                (click)="onSubmit()"
                [disabled]="editForm.invalid || isLoading || !hasChanges()">
          <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
          <mat-icon *ngIf="!isLoading">save</mat-icon>
          <span *ngIf="!isLoading">Salvar Alterações</span>
        </button>
      </mat-dialog-actions>
    </div>
  `,
  styles: [`
    .edit-campaign-modal {
      max-width: 600px;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .modal-header h2 {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0;
      color: var(--text-dark);
    }

    .modal-header mat-icon {
      color: var(--primary-blue);
    }

    .full-width {
      width: 100%;
      margin-bottom: 16px;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 16px;
    }

    .campaign-info {
      background: #f8f9fa;
      padding: 16px;
      border-radius: 8px;
      margin-top: 16px;
    }

    .campaign-info h4 {
      margin: 0 0 16px 0;
      color: var(--text-dark);
      font-size: 14px;
      font-weight: 500;
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .info-item .label {
      font-size: 12px;
      color: var(--text-light);
    }

    .info-item .value {
      font-size: 14px;
      color: var(--text-dark);
      font-weight: 500;
    }

    .info-item .value.active {
      color: var(--success);
    }

    .info-item .value.inactive {
      color: var(--text-light);
    }

    mat-dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
      margin-top: 24px;
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 480px) {
      .form-row {
        grid-template-columns: 1fr;
        gap: 0;
      }

      .info-grid {
        grid-template-columns: 1fr;
        gap: 8px;
      }
    }
  `]
})
export class EditCampaignModalComponent implements OnInit {
  editForm: FormGroup;
  isLoading = false;
  minDate = new Date();
  maxDate = new Date(new Date().setFullYear(new Date().getFullYear() + 2));
  originalFormValue: any;

  constructor(
    private fb: FormBuilder,
    private campaignsService: CampaignsService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<EditCampaignModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { campaign: Campaign }
  ) {
    this.editForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(10)]],
      description: ['', [Validators.required, Validators.minLength(50)]],
      targetAmount: ['', [Validators.required, Validators.min(100)]],
      endDate: ['', [Validators.required]],
      imageUrl: ['', [Validators.pattern(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)]]
    });
  }

  get campaign(): Campaign {
    return this.data.campaign;
  }

  ngOnInit() {
    // Populate form with current campaign data
    this.editForm.patchValue({
      title: this.campaign.title,
      description: this.campaign.description,
      targetAmount: this.campaign.targetAmount,
      endDate: new Date(this.campaign.endDate),
      imageUrl: this.campaign.imageUrl
    });
    
    this.originalFormValue = this.editForm.value;
  }

  hasChanges(): boolean {
    return JSON.stringify(this.editForm.value) !== JSON.stringify(this.originalFormValue);
  }

  onSubmit() {
    if (this.editForm.valid && this.hasChanges()) {
      this.isLoading = true;
      
      const updateData = { ...this.editForm.value };
      
      // Format date for backend
      if (updateData.endDate instanceof Date) {
        updateData.endDate = updateData.endDate.toISOString().split('T')[0];
      }
      
      this.campaignsService.updateCampaign(this.campaign.id, updateData).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.dialogRef.close(true);
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao atualizar campanha. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}