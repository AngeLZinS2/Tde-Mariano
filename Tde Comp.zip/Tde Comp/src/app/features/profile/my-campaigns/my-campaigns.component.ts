import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CampaignsService, Campaign } from '../../../core/services/campaigns.service';
import { EditCampaignModalComponent } from './edit-campaign-modal/edit-campaign-modal.component';

@Component({
  selector: 'app-my-campaigns',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDialogModule,
    MatTooltipModule
  ],
  template: `
    <div class="my-campaigns-container">
      <div class="campaigns-header">
        <h3>
          <mat-icon>campaign</mat-icon>
          Minhas Campanhas
        </h3>
        <a mat-raised-button color="primary" routerLink="/nova-campanha">
          <mat-icon>add</mat-icon>
          Nova Campanha
        </a>
      </div>

      <div *ngIf="isLoading" class="loading-spinner">
        <mat-spinner></mat-spinner>
        <p>Carregando suas campanhas...</p>
      </div>

      <div *ngIf="!isLoading && campaigns.length === 0" class="no-campaigns">
        <mat-icon>campaign</mat-icon>
        <h4>Você ainda não criou nenhuma campanha</h4>
        <p>Crie sua primeira campanha e comece a arrecadar fundos para sua causa.</p>
        <a mat-raised-button color="primary" routerLink="/nova-campanha">
          <mat-icon>add</mat-icon>
          Criar Primeira Campanha
        </a>
      </div>

      <div *ngIf="!isLoading && campaigns.length > 0" class="campaigns-grid">
        <mat-card *ngFor="let campaign of campaigns" class="campaign-card">
          <div class="campaign-image-container">
            <img [src]="campaign.imageUrl" 
                 [alt]="campaign.title" 
                 class="campaign-image"
                 (error)="onImageError($event)">
            <div class="campaign-status" [class.inactive]="!campaign.isActive">
              {{ campaign.isActive ? 'Ativa' : 'Encerrada' }}
            </div>
          </div>

          <mat-card-content>
            <h4 class="campaign-title">{{ campaign.title }}</h4>
            <p class="campaign-description">{{ campaign.description }}</p>

            <div class="progress-section">
              <div class="progress-header">
                <span class="progress-label">Progresso</span>
                <span class="progress-percentage">{{ getProgressPercentage(campaign) }}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill" 
                     [style.width.%]="getProgressPercentage(campaign)">
                </div>
              </div>
              <div class="progress-details">
                <div class="amount-raised">
                  <span class="label">Arrecadado:</span>
                  <span class="amount">R$ {{ campaign.currentAmount | number:'1.2-2' }}</span>
                </div>
                <div class="amount-target">
                  <span class="label">Meta:</span>
                  <span class="amount">R$ {{ campaign.targetAmount | number:'1.2-2' }}</span>
                </div>
              </div>
            </div>

            <div class="campaign-stats">
              <div class="stat-item">
                <mat-icon>volunteer_activism</mat-icon>
                <span>{{ campaign.donationsCount || 0 }} doações</span>
              </div>
              <div class="stat-item">
                <mat-icon>event</mat-icon>
                <span>Encerra: {{ campaign.endDate | date:'dd/MM/yyyy' }}</span>
              </div>
            </div>
          </mat-card-content>

          <mat-card-actions>
            <button mat-button 
                    color="primary" 
                    (click)="editCampaign(campaign)"
                    matTooltip="Editar campanha">
              <mat-icon>edit</mat-icon>
              Editar
            </button>
            <button mat-button 
                    [color]="campaign.isActive ? 'warn' : 'primary'"
                    (click)="toggleCampaignStatus(campaign)"
                    [matTooltip]="campaign.isActive ? 'Encerrar campanha' : 'Reativar campanha'">
              <mat-icon>{{ campaign.isActive ? 'stop' : 'play_arrow' }}</mat-icon>
              {{ campaign.isActive ? 'Encerrar' : 'Reativar' }}
            </button>
          </mat-card-actions>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .my-campaigns-container {
      margin-top: 24px;
    }

    .campaigns-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }

    .campaigns-header h3 {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0;
      color: var(--text-dark);
    }

    .campaigns-header h3 mat-icon {
      color: var(--primary-blue);
    }

    .loading-spinner {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 3rem;
    }

    .loading-spinner p {
      margin-top: 1rem;
      color: var(--text-light);
    }

    .no-campaigns {
      text-align: center;
      padding: 3rem;
      color: var(--text-light);
    }

    .no-campaigns mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 16px;
      color: var(--text-light);
    }

    .no-campaigns h4 {
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .no-campaigns p {
      margin-bottom: 24px;
    }

    .campaigns-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 24px;
    }

    .campaign-card {
      overflow: hidden;
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .campaign-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
    }

    .campaign-image-container {
      position: relative;
      height: 180px;
      overflow: hidden;
    }

    .campaign-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .campaign-status {
      position: absolute;
      top: 12px;
      right: 12px;
      background: var(--success);
      color: white;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }

    .campaign-status.inactive {
      background: var(--text-light);
    }

    .campaign-title {
      margin: 0 0 12px 0;
      color: var(--text-dark);
      font-size: 1.1rem;
      font-weight: 500;
    }

    .campaign-description {
      color: var(--text-light);
      font-size: 14px;
      margin-bottom: 16px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.4;
    }

    .progress-section {
      margin-bottom: 16px;
    }

    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .progress-label {
      font-size: 14px;
      color: var(--text-dark);
      font-weight: 500;
    }

    .progress-percentage {
      font-size: 14px;
      color: var(--primary-green);
      font-weight: 600;
    }

    .progress-bar {
      width: 100%;
      height: 6px;
      background: #e0e0e0;
      border-radius: 3px;
      overflow: hidden;
      margin-bottom: 8px;
    }

    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--primary-green), var(--accent-green));
      transition: width 0.3s ease;
    }

    .progress-details {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
    }

    .progress-details .label {
      color: var(--text-light);
    }

    .progress-details .amount {
      color: var(--text-dark);
      font-weight: 500;
    }

    .campaign-stats {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
    }

    .stat-item {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      color: var(--text-light);
    }

    .stat-item mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    mat-card-actions {
      display: flex;
      justify-content: space-between;
      padding: 16px;
    }

    @media (max-width: 768px) {
      .campaigns-header {
        flex-direction: column;
        gap: 16px;
        align-items: stretch;
      }

      .campaigns-grid {
        grid-template-columns: 1fr;
        gap: 16px;
      }

      mat-card-actions {
        flex-direction: column;
        gap: 8px;
      }
    }
  `]
})
export class MyCampaignsComponent implements OnInit {
  campaigns: Campaign[] = [];
  isLoading = true;

  constructor(
    private campaignsService: CampaignsService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadMyCampaigns();
  }

  loadMyCampaigns() {
    this.isLoading = true;
    
    this.campaignsService.getMyCampaigns().subscribe({
      next: (campaigns) => {
        this.campaigns = campaigns;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Erro ao carregar suas campanhas', 'Fechar', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  getProgressPercentage(campaign: Campaign): number {
    return Math.min(Math.round((campaign.currentAmount / campaign.targetAmount) * 100), 100);
  }

  editCampaign(campaign: Campaign) {
    const dialogRef = this.dialog.open(EditCampaignModalComponent, {
      width: '600px',
      data: { campaign }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadMyCampaigns();
      }
    });
  }

  toggleCampaignStatus(campaign: Campaign) {
    const action = campaign.isActive ? 'encerrar' : 'reativar';
    
    this.campaignsService.toggleCampaignStatus(campaign.id).subscribe({
      next: (result) => {
        if (result.success) {
          this.snackBar.open(result.message, 'Fechar', {
            duration: 3000,
            panelClass: ['success-snackbar']
          });
          this.loadMyCampaigns();
        } else {
          this.snackBar.open(result.message, 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      },
      error: () => {
        this.snackBar.open(`Erro ao ${action} campanha. Tente novamente.`, 'Fechar', {
          duration: 4000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  onImageError(event: any) {
    event.target.src = 'https://images.pexels.com/photos/6647100/pexels-photo-6647100.jpeg?auto=compress&cs=tinysrgb&w=800';
  }
}