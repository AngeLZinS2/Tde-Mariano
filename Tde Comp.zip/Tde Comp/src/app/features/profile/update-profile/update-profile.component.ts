import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { AuthService, User } from '../../../core/services/auth.service';
import { MyCampaignsComponent } from '../my-campaigns/my-campaigns.component';

@Component({
  selector: 'app-update-profile',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTabsModule,
    MyCampaignsComponent
  ],
  template: `
    <div class="page-content">
      <div class="container">
        <div class="page-header">
          <h1>
            <mat-icon>person</mat-icon>
            Meu Perfil
          </h1>
          <p>Gerencie suas informações pessoais e campanhas</p>
        </div>

        <div class="profile-container">
          <div class="profile-sidebar">
            <div class="profile-avatar">
              <div class="avatar-circle">
                <mat-icon>account_circle</mat-icon>
              </div>
              <h3>{{ currentUser?.name }}</h3>
              <p>{{ currentUser?.email }}</p>
              <button mat-button color="primary" class="change-photo-btn">
                <mat-icon>camera_alt</mat-icon>
                Alterar Foto
              </button>
            </div>

            <div class="profile-menu">
              <a mat-button class="menu-item" [class.active]="selectedTab === 0" (click)="selectedTab = 0">
                <mat-icon>person</mat-icon>
                Informações Pessoais
              </a>
              <a mat-button class="menu-item" [class.active]="selectedTab === 1" (click)="selectedTab = 1">
                <mat-icon>campaign</mat-icon>
                Minhas Campanhas
              </a>
              <a mat-button routerLink="/alterar-senha" class="menu-item">
                <mat-icon>lock</mat-icon>
                Alterar Senha
              </a>
              <a mat-button class="menu-item">
                <mat-icon>notifications</mat-icon>
                Notificações
              </a>
              <a mat-button class="menu-item">
                <mat-icon>security</mat-icon>
                Privacidade
              </a>
            </div>
          </div>

          <div class="profile-content">
            <!-- Personal Information Tab -->
            <div *ngIf="selectedTab === 0">
              <mat-card class="profile-form-card">
                <mat-card-header>
                  <mat-card-title>Informações Pessoais</mat-card-title>
                  <mat-card-subtitle>Atualize seus dados pessoais</mat-card-subtitle>
                </mat-card-header>

                <mat-card-content>
                  <form [formGroup]="profileForm" (ngSubmit)="onSubmit()">
                    <div class="form-grid">
                      <mat-form-field appearance="outline">
                        <mat-label>Nome Completo</mat-label>
                        <input matInput
                               formControlName="name"
                               placeholder="Seu nome completo">
                        <mat-icon matSuffix>person</mat-icon>
                        <mat-error *ngIf="profileForm.get('name')?.hasError('required')">
                          Nome é obrigatório
                        </mat-error>
                        <mat-error *ngIf="profileForm.get('name')?.hasError('minlength')">
                          Nome deve ter pelo menos 3 caracteres
                        </mat-error>
                      </mat-form-field>

                      <mat-form-field appearance="outline">
                        <mat-label>CPF</mat-label>
                        <input matInput
                               formControlName="cpf"
                               placeholder="000.000.000-00"
                               readonly>
                        <mat-icon matSuffix>badge</mat-icon>
                        <mat-hint>CPF não pode ser alterado</mat-hint>
                      </mat-form-field>
                    </div>

                    <div class="form-grid">
                      <mat-form-field appearance="outline">
                        <mat-label>Email</mat-label>
                        <input matInput
                               type="email"
                               formControlName="email"
                               placeholder="seu@email.com">
                        <mat-icon matSuffix>email</mat-icon>
                        <mat-error *ngIf="profileForm.get('email')?.hasError('required')">
                          Email é obrigatório
                        </mat-error>
                        <mat-error *ngIf="profileForm.get('email')?.hasError('email')">
                          Email deve ser válido
                        </mat-error>
                      </mat-form-field>

                      <mat-form-field appearance="outline">
                        <mat-label>Telefone</mat-label>
                        <input matInput
                               formControlName="phone"
                               placeholder="(11) 99999-9999"
                               mask="(00) 00000-0000">
                        <mat-icon matSuffix>phone</mat-icon>
                      </mat-form-field>
                    </div>

                    <mat-form-field appearance="outline" class="full-width">
                      <mat-label>URL da Foto de Perfil</mat-label>
                      <input matInput
                             type="url"
                             formControlName="photo"
                             placeholder="https://exemplo.com/foto.jpg">
                      <mat-icon matSuffix>image</mat-icon>
                      <mat-error *ngIf="profileForm.get('photo')?.hasError('pattern')">
                        URL da foto deve ser válida
                      </mat-error>
                    </mat-form-field>

                    <div class="profile-stats">
                      <h4>Estatísticas da Conta</h4>
                      <div class="stats-grid">
                        <div class="stat-item">
                          <mat-icon>volunteer_activism</mat-icon>
                          <div class="stat-content">
                            <span class="stat-number">12</span>
                            <span class="stat-label">Doações Realizadas</span>
                          </div>
                        </div>
                        <div class="stat-item">
                          <mat-icon>monetization_on</mat-icon>
                          <div class="stat-content">
                            <span class="stat-number">R$ 2.450</span>
                            <span class="stat-label">Total Doado</span>
                          </div>
                        </div>
                        <div class="stat-item">
                          <mat-icon>campaign</mat-icon>
                          <div class="stat-content">
                            <span class="stat-number">3</span>
                            <span class="stat-label">Campanhas Criadas</span>
                          </div>
                        </div>
                        <div class="stat-item">
                          <mat-icon>event</mat-icon>
                          <div class="stat-content">
                            <span class="stat-number">{{ getAccountAge() }}</span>
                            <span class="stat-label">Meses na Plataforma</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="form-actions">
                      <button mat-button type="button" (click)="resetForm()">
                        Cancelar
                      </button>
                      <button mat-raised-button
                              color="primary"
                              type="submit"
                              [disabled]="profileForm.invalid || isLoading || !hasChanges()">
                        <mat-spinner diameter="20" *ngIf="isLoading"></mat-spinner>
                        <mat-icon *ngIf="!isLoading">save</mat-icon>
                        <span *ngIf="!isLoading">Salvar Alterações</span>
                      </button>
                    </div>
                  </form>
                </mat-card-content>
              </mat-card>
            </div>

            <!-- My Campaigns Tab -->
            <div *ngIf="selectedTab === 1">
              <app-my-campaigns></app-my-campaigns>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-header {
      text-align: center;
      margin-bottom: 2rem;
    }

    .page-header h1 {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin: 0 0 8px 0;
      color: var(--text-dark);
    }

    .page-header h1 mat-icon {
      font-size: 32px;
      color: var(--primary-blue);
    }

    .page-header p {
      color: var(--text-light);
      margin: 0;
    }

    .profile-container {
      display: grid;
      grid-template-columns: 280px 1fr;
      gap: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .profile-sidebar {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .profile-avatar {
      background: white;
      padding: 24px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      text-align: center;
    }

    .avatar-circle {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: var(--primary-blue);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      color: white;
    }

    .avatar-circle mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
    }

    .profile-avatar h3 {
      margin: 0 0 4px 0;
      color: var(--text-dark);
      font-size: 18px;
    }

    .profile-avatar p {
      margin: 0 0 16px 0;
      color: var(--text-light);
      font-size: 14px;
    }

    .change-photo-btn {
      font-size: 12px;
    }

    .profile-menu {
      background: white;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .menu-item {
      display: flex;
      align-items: center;
      gap: 12px;
      width: 100%;
      padding: 16px 20px;
      text-align: left;
      justify-content: flex-start;
      border-radius: 0;
      color: var(--text-light);
      transition: all 0.2s;
    }

    .menu-item:hover {
      background: #f5f5f5;
      color: var(--primary-blue);
    }

    .menu-item.active {
      background: var(--primary-blue);
      color: white;
    }

    .menu-item mat-icon {
      font-size: 20px;
      width: 20px;
      height: 20px;
    }

    .profile-content {
      flex: 1;
    }

    .profile-form-card {
      padding: 0;
    }

    mat-card-header {
      margin-bottom: 24px;
    }

    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 24px;
    }

    .full-width {
      width: 100%;
      margin-bottom: 24px;
    }

    .profile-stats {
      background: #f8f9fa;
      padding: 24px;
      border-radius: 8px;
      margin: 24px 0;
    }

    .profile-stats h4 {
      margin: 0 0 16px 0;
      color: var(--text-dark);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }

    .stat-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      background: white;
      border-radius: 8px;
    }

    .stat-item mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
      color: var(--primary-green);
    }

    .stat-content {
      display: flex;
      flex-direction: column;
    }

    .stat-number {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-dark);
    }

    .stat-label {
      font-size: 12px;
      color: var(--text-light);
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 16px;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid #e0e0e0;
    }

    mat-spinner {
      margin-right: 8px;
    }

    @media (max-width: 768px) {
      .profile-container {
        grid-template-columns: 1fr;
        gap: 16px;
      }

      .profile-sidebar {
        order: 2;
      }

      .profile-content {
        order: 1;
      }

      .form-grid {
        grid-template-columns: 1fr;
        gap: 0;
      }

      .stats-grid {
        grid-template-columns: 1fr;
        gap: 12px;
      }

      .form-actions {
        flex-direction: column-reverse;
        gap: 8px;
      }
    }
  `]
})
export class UpdateProfileComponent implements OnInit {
  profileForm: FormGroup;
  isLoading = false;
  currentUser: User | null = null;
  originalFormValue: any;
  selectedTab = 0;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private snackBar: MatSnackBar
  ) {
    this.profileForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      cpf: [''],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      photo: ['', [Validators.pattern(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)]]
    });
  }

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    if (this.currentUser) {
      this.profileForm.patchValue({
        name: this.currentUser.name,
        cpf: this.currentUser.cpf,
        email: this.currentUser.email,
        phone: this.currentUser.phone || '',
        photo: this.currentUser.photo || ''
      });
      this.originalFormValue = this.profileForm.value;
    }
  }

  hasChanges(): boolean {
    return JSON.stringify(this.profileForm.value) !== JSON.stringify(this.originalFormValue);
  }

  resetForm() {
    this.profileForm.patchValue(this.originalFormValue);
  }

  getAccountAge(): number {
    // Mock calculation - in real app, this would be based on user creation date
    return Math.floor(Math.random() * 24) + 1;
  }

  onSubmit() {
    if (this.profileForm.valid && this.hasChanges()) {
      this.isLoading = true;
      
      // Remove CPF from update data as it shouldn't be changed
      const updateData = { ...this.profileForm.value };
      delete updateData.cpf;
      
      this.authService.updateProfile(updateData).subscribe({
        next: (result) => {
          this.isLoading = false;
          
          if (result.success) {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 3000,
              panelClass: ['success-snackbar']
            });
            this.originalFormValue = this.profileForm.value;
            this.currentUser = result.user ?? null;
          } else {
            this.snackBar.open(result.message, 'Fechar', {
              duration: 4000,
              panelClass: ['error-snackbar']
            });
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Erro ao atualizar perfil. Tente novamente.', 'Fechar', {
            duration: 4000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}