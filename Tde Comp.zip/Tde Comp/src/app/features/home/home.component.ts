import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { CampaignsService, Campaign } from '../../core/services/campaigns.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, MatButtonModule, MatCardModule, MatIconModule],
  template: `
    <div class="home-page">
      <!-- Hero Section -->
      <section class="hero-section">
        <div class="container">
          <h1 class="hero-title">Transformando Vidas Através da Solidariedade</h1>
          <p class="hero-subtitle">
            A ONG Esperança é uma organização dedicada a promover mudanças positivas na sociedade,
            oferecendo apoio às comunidades mais necessitadas e construindo um futuro melhor para todos.
          </p>
          <div class="hero-actions">
            <ng-container *ngIf="authService.isAuthenticated(); else guestActions">
              <a mat-raised-button color="accent" routerLink="/doacoes" class="cta-button">
                Conhecer Campanhas
              </a>
              <a mat-stroked-button routerLink="/nova-campanha" class="secondary-button">
                Criar Campanha
              </a>
            </ng-container>
            <ng-template #guestActions>
              <a mat-raised-button color="accent" routerLink="/login" class="cta-button">
                Entrar para Doar
              </a>
              <a mat-stroked-button routerLink="/cadastro" class="secondary-button">
                Junte-se a Nós
              </a>
            </ng-template>
          </div>
        </div>
      </section>

      <!-- Stats Section -->
      <section class="section">
        <div class="container">
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-number">1,250+</div>
              <div class="stat-label">Famílias Atendidas</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">R$ 850K</div>
              <div class="stat-label">Arrecadados em 2024</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">45</div>
              <div class="stat-label">Campanhas Ativas</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">2,800+</div>
              <div class="stat-label">Doadores Cadastrados</div>
            </div>
          </div>
        </div>
      </section>

      <!-- Mission, Vision, Values -->
      <section class="section" style="background: white;">
        <div class="container">
          <h2 class="section-title">Nossa Essência</h2>
          <div class="values-grid">
            <mat-card class="value-card">
              <mat-card-content>
                <div class="value-icon">
                  <mat-icon>track_changes</mat-icon>
                </div>
                <h3>Missão</h3>
                <p>
                  Promover a transformação social através de ações solidárias, 
                  oferecendo oportunidades e dignidade às comunidades em situação de vulnerabilidade.
                </p>
              </mat-card-content>
            </mat-card>

            <mat-card class="value-card">
              <mat-card-content>
                <div class="value-icon">
                  <mat-icon>visibility</mat-icon>
                </div>
                <h3>Visão</h3>
                <p>
                  Ser reconhecida como uma organização de referência em responsabilidade social,
                  contribuindo para a construção de uma sociedade mais justa e igualitária.
                </p>
              </mat-card-content>
            </mat-card>

            <mat-card class="value-card">
              <mat-card-content>
                <div class="value-icon">
                  <mat-icon>favorite</mat-icon>
                </div>
                <h3>Valores</h3>
                <p>
                  Transparência, solidariedade, respeito à dignidade humana, 
                  compromisso social e sustentabilidade em todas as nossas ações.
                </p>
              </mat-card-content>
            </mat-card>
          </div>
        </div>
      </section>

      <!-- Featured Campaigns -->
      <section class="section">
        <div class="container">
          <h2 class="section-title">Campanhas em Destaque</h2>
          <div class="campaigns-grid">
            <mat-card *ngFor="let campaign of featuredCampaigns" class="campaign-card">
              <div class="campaign-image-container">
                <img [src]="campaign.imageUrl" [alt]="campaign.title" class="campaign-image">
                <div class="campaign-progress-overlay">
                  <div class="progress-bar">
                    <div class="progress-fill" [style.width.%]="getProgressPercentage(campaign)"></div>
                  </div>
                  <span class="progress-text">{{ getProgressPercentage(campaign) }}% da meta</span>
                </div>
              </div>
              <mat-card-content>
                <h3>{{ campaign.title }}</h3>
                <p class="campaign-description">{{ campaign.description }}</p>
                <div class="campaign-stats">
                  <div class="stat">
                    <strong>Meta:</strong> R$ {{ campaign.targetAmount | number:'1.2-2' }}
                  </div>
                  <div class="stat">
                    <strong>Arrecadado:</strong> R$ {{ campaign.currentAmount | number:'1.2-2' }}
                  </div>
                </div>
              </mat-card-content>
              <mat-card-actions>
                <ng-container *ngIf="authService.isAuthenticated(); else loginPrompt">
                  <a mat-button color="primary" routerLink="/doacoes">Ver Detalhes</a>
                  <a mat-raised-button color="primary" routerLink="/doacoes">Doar Agora</a>
                </ng-container>
                <ng-template #loginPrompt>
                  <a mat-button color="primary" routerLink="/login">Entrar para Doar</a>
                  <a mat-raised-button color="primary" routerLink="/cadastro">Cadastrar</a>
                </ng-template>
              </mat-card-actions>
            </mat-card>
          </div>
          
          <div class="text-center mt-3">
            <ng-container *ngIf="authService.isAuthenticated(); else loginButton">
              <a mat-raised-button color="primary" routerLink="/doacoes">
                Ver Todas as Campanhas
              </a>
            </ng-container>
            <ng-template #loginButton>
              <a mat-raised-button color="primary" routerLink="/login">
                Entrar para Ver Campanhas
              </a>
            </ng-template>
          </div>
        </div>
      </section>

      <!-- How to Help -->
      <section class="section" style="background: white;">
        <div class="container">
          <h2 class="section-title">Como Você Pode Ajudar</h2>
          <div class="help-options">
            <div class="help-option">
              <mat-icon class="help-icon">volunteer_activism</mat-icon>
              <h4>Faça uma Doação</h4>
              <p>Contribua financeiramente com nossas campanhas e projetos sociais.</p>
              <ng-container *ngIf="authService.isAuthenticated(); else loginToDonate">
                <a mat-button color="primary" routerLink="/doacoes">Doar Agora</a>
              </ng-container>
              <ng-template #loginToDonate>
                <a mat-button color="primary" routerLink="/login">Entrar para Doar</a>
              </ng-template>
            </div>
            <div class="help-option">
              <mat-icon class="help-icon">people</mat-icon>
              <h4>Seja Voluntário</h4>
              <p>Doe seu tempo e conhecimento para ajudar em nossas atividades.</p>
              <a mat-button color="primary" routerLink="/cadastro">Cadastre-se</a>
            </div>
            <div class="help-option">
              <mat-icon class="help-icon">share</mat-icon>
              <h4>Divulgue</h4>
              <p>Compartilhe nossas campanhas em suas redes sociais e ajude a alcançar mais pessoas.</p>
              <button mat-button color="primary">Compartilhar</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .home-page {
      min-height: calc(100vh - 64px);
    }

    .campaigns-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 24px;
      margin-bottom: 2rem;
    }

    .campaign-card {
      overflow: hidden;
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .campaign-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    }

    .campaign-image-container {
      position: relative;
      height: 200px;
      overflow: hidden;
    }

    .campaign-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .campaign-progress-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(0,0,0,0.7));
      padding: 16px;
      color: white;
    }

    .progress-bar {
      width: 100%;
      height: 8px;
      background: rgba(255,255,255,0.3);
      border-radius: 4px;
      overflow: hidden;
      margin-bottom: 8px;
    }

    .progress-fill {
      height: 100%;
      background: var(--primary-green);
      transition: width 0.3s ease;
    }

    .progress-text {
      font-size: 12px;
      font-weight: 500;
    }

    .campaign-description {
      font-size: 14px;
      color: var(--text-light);
      margin: 12px 0;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .campaign-stats {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      margin-top: 16px;
    }

    .help-options {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 32px;
    }

    .help-option {
      text-align: center;
      padding: 24px;
    }

    .help-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: var(--primary-green);
      margin-bottom: 16px;
    }

    .help-option h4 {
      margin: 16px 0 8px;
      color: var(--text-dark);
    }

    .help-option p {
      color: var(--text-light);
      margin-bottom: 16px;
      line-height: 1.5;
    }

    .cta-button {
      background: white !important;
      color: var(--primary-blue) !important;
      margin-right: 16px;
    }

    .secondary-button {
      border-color: white !important;
      color: white !important;
    }

    .hero-actions {
      margin-top: 32px;
    }

    @media (max-width: 768px) {
      .campaigns-grid {
        grid-template-columns: 1fr;
        gap: 16px;
      }

      .help-options {
        gap: 24px;
      }

      .hero-actions {
        display: flex;
        flex-direction: column;
        gap: 12px;
        align-items: center;
      }

      .cta-button {
        margin-right: 0 !important;
      }
    }
  `]
})
export class HomeComponent implements OnInit {
  featuredCampaigns: Campaign[] = [];

  constructor(
    private campaignsService: CampaignsService,
    public authService: AuthService
  ) {}

  ngOnInit() {
    this.loadFeaturedCampaigns();
  }

  loadFeaturedCampaigns() {
    this.campaignsService.getActiveCampaigns().subscribe(campaigns => {
      this.featuredCampaigns = campaigns.slice(0, 3); // Show first 3 campaigns
    });
  }

  getProgressPercentage(campaign: Campaign): number {
    return Math.round((campaign.currentAmount / campaign.targetAmount) * 100);
  }
}