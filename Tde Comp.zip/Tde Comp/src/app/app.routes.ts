import { Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { AdminGuard } from './core/guards/admin.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'cadastro',
    loadComponent: () => import('./features/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'doadores',
    loadComponent: () => import('./features/donors/donors-list/donors-list.component').then(m => m.DonorsListComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'nova-campanha',
    loadComponent: () => import('./features/campaigns/create-campaign/create-campaign.component').then(m => m.CreateCampaignComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'doacoes',
    loadComponent: () => import('./features/donations/donations.component').then(m => m.DonationsComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'alterar-senha',
    loadComponent: () => import('./features/auth/change-password/change-password.component').then(m => m.ChangePasswordComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'perfil',
    loadComponent: () => import('./features/profile/update-profile/update-profile.component').then(m => m.UpdateProfileComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'admin',
    loadComponent: () => import('./features/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent),
    canActivate: [AdminGuard]
  },
  {
    path: 'admin/users',
    loadComponent: () => import('./features/admin/admin-users/admin-users.component').then(m => m.AdminUsersComponent),
    canActivate: [AdminGuard]
  },
  {
    path: 'admin/campaigns',
    loadComponent: () => import('./features/admin/admin-campaigns/admin-campaigns.component').then(m => m.AdminCampaignsComponent),
    canActivate: [AdminGuard]
  },
  {
    path: '**',
    redirectTo: ''
  }
];