import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIconModule, MatButtonModule],
  template: `
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-section">
            <h3>ONG Esperança</h3>
            <p>Transformando vidas através de ações sociais e solidariedade. Juntos construímos um mundo melhor.</p>
            <div class="social-links">
              <button mat-icon-button aria-label="Facebook">
                <mat-icon>facebook</mat-icon>
              </button>
              <button mat-icon-button aria-label="Instagram">
                <mat-icon>camera_alt</mat-icon>
              </button>
              <button mat-icon-button aria-label="Twitter">
                <mat-icon>alternate_email</mat-icon>
              </button>
              <button mat-icon-button aria-label="YouTube">
                <mat-icon>play_circle_outline</mat-icon>
              </button>
            </div>
          </div>
          
          <div class="footer-section">
            <h4>Links Rápidos</h4>
            <nav class="footer-nav">
              <a routerLink="/">Início</a>
              <a routerLink="/doacoes">Doações</a>
              <a routerLink="/login">Entrar</a>
              <a routerLink="/cadastro">Cadastrar</a>
            </nav>
          </div>
          
          <div class="footer-section">
            <h4>Contato</h4>
            <div class="contact-info">
              <p><mat-icon>email</mat-icon> contato&#64;ongesperanca.org.br</p>
              <p><mat-icon>phone</mat-icon> (11) 3456-7890</p>
              <p><mat-icon>location_on</mat-icon> Rua da Esperança, 123 - São Paulo, SP</p>
            </div>
          </div>
          
          <div class="footer-section">
            <h4>Transparência</h4>
            <div class="transparency-links">
              <a href="#" target="_blank">Relatório Anual</a>
              <a href="#" target="_blank">Prestação de Contas</a>
              <a href="#" target="_blank">Certificações</a>
              <a href="#" target="_blank">Política de Privacidade</a>
            </div>
          </div>
        </div>
        
        <div class="footer-bottom">
          <p>&copy; {{ currentYear }} ONG Esperança. Todos os direitos reservados.</p>
          <p>CNPJ: 12.345.678/0001-90 | Utilidade Pública Federal</p>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background: linear-gradient(135deg, #2C3E50, #34495E);
      color: white;
      padding: 60px 0 20px;
      margin-top: auto;
    }
    
    .footer-content {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 40px;
      margin-bottom: 40px;
    }
    
    .footer-section h3 {
      color: var(--accent-green);
      margin-bottom: 16px;
      font-size: 24px;
    }
    
    .footer-section h4 {
      color: var(--accent-blue);
      margin-bottom: 16px;
      font-size: 18px;
    }
    
    .footer-section p {
      line-height: 1.6;
      margin-bottom: 16px;
      opacity: 0.9;
    }
    
    .social-links {
      display: flex;
      gap: 8px;
    }
    
    .social-links button {
      color: white;
    }
    
    .footer-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    
    .footer-nav a {
      color: white;
      text-decoration: none;
      opacity: 0.9;
      transition: opacity 0.2s;
    }
    
    .footer-nav a:hover {
      opacity: 1;
      color: var(--accent-green);
    }
    
    .contact-info p {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
    }
    
    .contact-info mat-icon {
      font-size: 18px;
      color: var(--accent-blue);
    }
    
    .transparency-links {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    
    .transparency-links a {
      color: white;
      text-decoration: none;
      opacity: 0.9;
      transition: opacity 0.2s;
    }
    
    .transparency-links a:hover {
      opacity: 1;
      color: var(--accent-green);
    }
    
    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 20px;
      text-align: center;
    }
    
    .footer-bottom p {
      margin: 4px 0;
      opacity: 0.8;
      font-size: 14px;
    }
    
    @media (max-width: 768px) {
      .footer {
        padding: 40px 0 20px;
      }
      
      .footer-content {
        gap: 30px;
      }
      
      .social-links {
        justify-content: center;
      }
    }
  `]
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
}