import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { AuthService, User } from '../../../core/services/auth.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatSidenavModule,
    MatListModule
  ],
  template: `
    <mat-toolbar color="primary" class="header-toolbar">
      <div class="container">
        <div class="header-content">
          <!-- Mobile menu button -->
          <button mat-icon-button (click)="sidenav.toggle()" class="mobile-menu-btn">
            <mat-icon>menu</mat-icon>
          </button>
          
          <!-- Logo -->
          <div class="logo" routerLink="/">
            <mat-icon class="logo-icon">favorite</mat-icon>
            <span class="logo-text">ONG Esperança</span>
          </div>
          
          <!-- Desktop navigation -->
          <nav class="desktop-nav">
            <a mat-button routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">
              Início
            </a>
            <ng-container *ngIf="currentUser$ | async as user">
              <a mat-button routerLink="/doacoes" routerLinkActive="active">
                Doações
              </a>
              <a mat-button routerLink="/doadores" routerLinkActive="active">
                Doadores
              </a>
              <a mat-button routerLink="/nova-campanha" routerLinkActive="active">
                Nova Campanha
              </a>
              <a mat-button routerLink="/admin" routerLinkActive="active" *ngIf="user.isAdmin" class="admin-link">
                <mat-icon>admin_panel_settings</mat-icon>
                Admin
              </a>
            </ng-container>
          </nav>
          
          <!-- User menu -->
          <div class="user-menu">
            <ng-container *ngIf="currentUser$ | async as user; else guestButtons">
              <button mat-button [matMenuTriggerFor]="userMenu" class="user-button">
                <mat-icon>account_circle</mat-icon>
                <span class="user-name">{{ user.name }}</span>
                <mat-icon>keyboard_arrow_down</mat-icon>
              </button>
              <mat-menu #userMenu="matMenu">
                <a mat-menu-item routerLink="/perfil">
                  <mat-icon>person</mat-icon>
                  <span>Meu Perfil</span>
                </a>
                <a mat-menu-item routerLink="/alterar-senha">
                  <mat-icon>lock</mat-icon>
                  <span>Alterar Senha</span>
                </a>
                <ng-container *ngIf="user.isAdmin">
                  <mat-divider></mat-divider>
                  <a mat-menu-item routerLink="/admin">
                    <mat-icon>admin_panel_settings</mat-icon>
                    <span>Painel Admin</span>
                  </a>
                  <a mat-menu-item routerLink="/admin/users">
                    <mat-icon>people</mat-icon>
                    <span>Gerenciar Usuários</span>
                  </a>
                </ng-container>
                <mat-divider></mat-divider>
                <button mat-menu-item (click)="logout()">
                  <mat-icon>logout</mat-icon>
                  <span>Sair</span>
                </button>
              </mat-menu>
            </ng-container>
            
            <ng-template #guestButtons>
              <a mat-button routerLink="/login" class="login-btn">
                Entrar
              </a>
              <a mat-raised-button routerLink="/cadastro" class="register-btn">
                Cadastrar
              </a>
            </ng-template>
          </div>
        </div>
      </div>
    </mat-toolbar>
    
    <!-- Mobile sidebar -->
    <mat-sidenav-container class="sidenav-container" [class.sidenav-open]="sidenav.opened">
      <mat-sidenav #sidenav mode="over" class="mobile-sidenav">
        <mat-nav-list>
          <a mat-list-item routerLink="/" (click)="sidenav.close()">
            <mat-icon matListItemIcon>home</mat-icon>
            <span matListItemTitle>Início</span>
          </a>
          <ng-container *ngIf="currentUser$ | async as user">
            <a mat-list-item routerLink="/doacoes" (click)="sidenav.close()">
              <mat-icon matListItemIcon>volunteer_activism</mat-icon>
              <span matListItemTitle>Doações</span>
            </a>
            <a mat-list-item routerLink="/doadores" (click)="sidenav.close()">
              <mat-icon matListItemIcon>people</mat-icon>
              <span matListItemTitle>Doadores</span>
            </a>
            <a mat-list-item routerLink="/nova-campanha" (click)="sidenav.close()">
              <mat-icon matListItemIcon>add_circle</mat-icon>
              <span matListItemTitle>Nova Campanha</span>
            </a>
            <ng-container *ngIf="user.isAdmin">
              <mat-divider></mat-divider>
              <a mat-list-item routerLink="/admin" (click)="sidenav.close()">
                <mat-icon matListItemIcon>admin_panel_settings</mat-icon>
                <span matListItemTitle>Painel Admin</span>
              </a>
              <a mat-list-item routerLink="/admin/users" (click)="sidenav.close()">
                <mat-icon matListItemIcon>people</mat-icon>
                <span matListItemTitle>Gerenciar Usuários</span>
              </a>
            </ng-container>
            <mat-divider></mat-divider>
            <a mat-list-item routerLink="/perfil" (click)="sidenav.close()">
              <mat-icon matListItemIcon>person</mat-icon>
              <span matListItemTitle>Meu Perfil</span>
            </a>
            <a mat-list-item routerLink="/alterar-senha" (click)="sidenav.close()">
              <mat-icon matListItemIcon>lock</mat-icon>
              <span matListItemTitle>Alterar Senha</span>
            </a>
            <a mat-list-item (click)="logout(); sidenav.close()">
              <mat-icon matListItemIcon>logout</mat-icon>
              <span matListItemTitle>Sair</span>
            </a>
          </ng-container>
          <ng-container *ngIf="!(currentUser$ | async)">
            <a mat-list-item routerLink="/login" (click)="sidenav.close()">
              <mat-icon matListItemIcon>login</mat-icon>
              <span matListItemTitle>Entrar</span>
            </a>
            <a mat-list-item routerLink="/cadastro" (click)="sidenav.close()">
              <mat-icon matListItemIcon>person_add</mat-icon>
              <span matListItemTitle>Cadastrar</span>
            </a>
          </ng-container>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content></mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .header-toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: linear-gradient(135deg, var(--primary-blue), var(--primary-green));
    }
    
    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    
    .mobile-menu-btn {
      display: none;
    }
    
    .logo {
      display: flex;
      align-items: center;
      cursor: pointer;
      text-decoration: none;
      color: white;
    }
    
    .logo-icon {
      margin-right: 8px;
      font-size: 28px;
    }
    
    .logo-text {
      font-size: 20px;
      font-weight: 500;
    }
    
    .desktop-nav {
      display: flex;
      gap: 16px;
    }
    
    .desktop-nav a {
      color: white;
    }
    
    .desktop-nav a.active {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .admin-link {
      background-color: rgba(255, 193, 7, 0.2) !important;
      border: 1px solid rgba(255, 193, 7, 0.5);
    }

    .admin-link mat-icon {
      margin-right: 4px;
    }
    
    .user-menu {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .user-button {
      color: white;
    }
    
    .user-name {
      margin: 0 8px;
      max-width: 120px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .login-btn {
      color: white;
    }
    
    .register-btn {
      background-color: white;
      color: var(--primary-blue);
    }
    
    .sidenav-container {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      pointer-events: none;
      z-index: 999;
      visibility: hidden;
    }
    
    .sidenav-container.sidenav-open {
      visibility: visible;
      pointer-events: auto;
    }
    
    .mobile-sidenav {
      width: 280px;
      pointer-events: auto;
      margin-top: 64px;
    }
    
    @media (max-width: 768px) {
      .mobile-menu-btn {
        display: block;
      }
      
      .desktop-nav {
        display: none;
      }
      
      .user-menu {
        display: none;
      }
    }
    
    @media (max-width: 480px) {
      .logo-text {
        display: none;
      }
    }
  `]
})
export class HeaderComponent implements OnInit {
  currentUser$: Observable<User | null>;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    this.currentUser$ = this.authService.currentUser$;
  }

  ngOnInit() {}

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}