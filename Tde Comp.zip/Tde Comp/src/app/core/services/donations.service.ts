import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

export interface DonationData {
  campaignId: number;
  amount: number;
  paymentMethod: string;
  donorName?: string;
  donorEmail?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DonationsService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  makeDonation(donationData: DonationData): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${this.apiUrl}/donations`, donationData, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error making donation:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  getPaymentMethods(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/donations/payment-methods`)
      .pipe(
        catchError(error => {
          console.error('Error fetching payment methods:', error);
          return throwError(() => error);
        })
      );
  }
}