import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';

export interface Donor {
  id: number;
  name: string;
  email: string;
  lastDonationDate: string;
  totalDonated: number;
  donationsCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class DonorsService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  getDonors(): Observable<Donor[]> {
    return this.http.get<Donor[]>(`${this.apiUrl}/donors`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error fetching donors:', error);
          return throwError(() => error);
        })
      );
  }

  getDonorsPaginated(page: number, pageSize: number): Observable<{data: Donor[], total: number}> {
    return this.http.get<Donor[]>(`${this.apiUrl}/donors`, { headers: this.getAuthHeaders() })
      .pipe(
        map(donors => {
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize;
          const paginatedData = donors.slice(startIndex, endIndex);
          return {
            data: paginatedData,
            total: donors.length
          };
        }),
        catchError(error => {
          console.error('Error fetching donors:', error);
          return throwError(() => error);
        })
      );
  }
}