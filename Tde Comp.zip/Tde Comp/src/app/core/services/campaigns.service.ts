import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

export interface Campaign {
  id: number;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  endDate: string;
  imageUrl: string;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  donationsCount?: number;
}

export interface CreateCampaignData {
  title: string;
  description: string;
  targetAmount: number;
  endDate: string;
  imageUrl?: string;
}

export interface UpdateCampaignData {
  title?: string;
  description?: string;
  targetAmount?: number;
  endDate?: string;
  imageUrl?: string;
}

@Injectable({
  providedIn: 'root'
})
export class CampaignsService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  getActiveCampaigns(): Observable<Campaign[]> {
    return this.http.get<Campaign[]>(`${this.apiUrl}/campaigns/active`)
      .pipe(
        catchError(error => {
          console.error('Error fetching active campaigns:', error);
          return throwError(() => error);
        })
      );
  }

  getAllCampaigns(): Observable<Campaign[]> {
    return this.http.get<Campaign[]>(`${this.apiUrl}/campaigns`)
      .pipe(
        catchError(error => {
          console.error('Error fetching campaigns:', error);
          return throwError(() => error);
        })
      );
  }

  getMyCampaigns(): Observable<Campaign[]> {
    return this.http.get<Campaign[]>(`${this.apiUrl}/campaigns/my-campaigns`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error fetching my campaigns:', error);
          return throwError(() => error);
        })
      );
  }

  getCampaignById(id: number): Observable<Campaign | undefined> {
    return this.http.get<Campaign>(`${this.apiUrl}/campaigns/${id}`)
      .pipe(
        catchError(error => {
          console.error('Error fetching campaign:', error);
          return throwError(() => error);
        })
      );
  }

  createCampaign(data: CreateCampaignData): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${this.apiUrl}/campaigns`, data, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error creating campaign:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  updateCampaign(id: number, data: UpdateCampaignData): Observable<{ success: boolean; message: string }> {
    return this.http.put<{ success: boolean; message: string }>(`${this.apiUrl}/campaigns/${id}`, data, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error updating campaign:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  toggleCampaignStatus(id: number): Observable<{ success: boolean; message: string }> {
    return this.http.put<{ success: boolean; message: string }>(`${this.apiUrl}/campaigns/${id}/toggle-status`, {}, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error toggling campaign status:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }
}