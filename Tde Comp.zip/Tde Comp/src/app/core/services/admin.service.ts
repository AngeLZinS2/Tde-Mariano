import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

export interface AdminUser {
  id: number;
  name: string;
  email: string;
  cpf: string;
  phone?: string;
  isAdmin: boolean;
  createdAt: string;
  campaignsCount: number;
  donationsCount: number;
  totalDonated: number;
}

export interface AdminStats {
  totalUsers: number;
  totalCampaigns: number;
  activeCampaigns: number;
  totalDonations: number;
  totalAmountDonated: number;
  recentUsers: number;
  recentDonations: number;
}

export interface AdminCampaign {
  id: number;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  endDate: string;
  imageUrl: string;
  isActive: boolean;
  isApproved: boolean;
  approvalDate?: string;
  createdBy: string;
  approvedBy?: string;
  createdAt: string;
  donationsCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  getAllUsers(): Observable<AdminUser[]> {
    return this.http.get<AdminUser[]>(`${this.apiUrl}/admin/users`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error fetching users:', error);
          return throwError(() => error);
        })
      );
  }

  toggleUserAdmin(userId: number): Observable<{ success: boolean; message: string }> {
    return this.http.put<{ success: boolean; message: string }>(`${this.apiUrl}/admin/users/${userId}/toggle-admin`, {}, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error toggling user admin status:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  getAdminStats(): Observable<AdminStats> {
    return this.http.get<AdminStats>(`${this.apiUrl}/admin/stats`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error fetching admin stats:', error);
          return throwError(() => error);
        })
      );
  }

  // Campaign management methods
  getAllCampaigns(): Observable<AdminCampaign[]> {
    return this.http.get<AdminCampaign[]>(`${this.apiUrl}/admin/campaigns`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error fetching campaigns:', error);
          return throwError(() => error);
        })
      );
  }

  toggleCampaignApproval(campaignId: number): Observable<{ success: boolean; message: string }> {
    return this.http.put<{ success: boolean; message: string }>(`${this.apiUrl}/admin/campaigns/${campaignId}/approve`, {}, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error toggling campaign approval:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  updateCampaignAdmin(campaignId: number, data: any): Observable<{ success: boolean; message: string }> {
    return this.http.put<{ success: boolean; message: string }>(`${this.apiUrl}/admin/campaigns/${campaignId}`, data, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error updating campaign:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }

  deleteCampaign(campaignId: number): Observable<{ success: boolean; message: string }> {
    return this.http.delete<{ success: boolean; message: string }>(`${this.apiUrl}/admin/campaigns/${campaignId}`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(error => {
          console.error('Error deleting campaign:', error);
          return throwError(() => error.error || { success: false, message: 'Erro no servidor' });
        })
      );
  }
}